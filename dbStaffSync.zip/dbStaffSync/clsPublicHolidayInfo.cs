﻿using ModelStaffSync;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace dbStaffSync
{
    public class clsPublicHolidayInfo
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset;
        clsGenFunc objGenFunc = new clsGenFunc();

        public clsPublicHolidayInfo() { 

        }

        public List<PublicHolidayType> getHolidayTypeList()
        {
            List<PublicHolidayType> lstPublicHolidayType = new List<PublicHolidayType>();
            DataTable dt = new DataTable();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT PubHolTypeID, PubHolTypeCode, PubHolTypeTitle FROM PubHolType";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                List<PublicHolidayType> objPublicHolidayType = JsonConvert.DeserializeObject<List<PublicHolidayType>>(DataTableToJSon);
                if (objPublicHolidayType.Count > 0)
                {
                    lstPublicHolidayType = objPublicHolidayType;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return lstPublicHolidayType;
        }

        public List<PublicHolidayInfo> getDateSpecificHolidayInfo(int ClientID, DateTime dtCurrentDate)
        {
            List<PublicHolidayInfo> objPublicHolidayInfoList = new List<PublicHolidayInfo>();
            DataTable dt = new DataTable();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = @"SELECT
                                        PubHolType.PubHolTypeID,
                                        PubHolType.PubHolTypeCode,
                                        PubHolType.PubHolTypeTitle,
                                        PubHolidayDetails.PubHolDetID,
                                        PubHolidayDetails.PubHolidayTitle,
                                        PubHolidayDetails.PubHolDate,
                                        PubHolType.PubHolTypeTitle,
                                        ClientMas.ClientID
                                    FROM
                                        ClientMas
                                        INNER JOIN (
                                            PublicHolidayMas
                                            INNER JOIN (
                                                PubHolType
                                                INNER JOIN PubHolidayDetails ON PubHolType.PubHolTypeID = PubHolidayDetails.PubHolTypeID
                                            ) ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID
                                        ) ON ClientMas.ClientID = PublicHolidayMas.ClientID
                                    WHERE
                                        (
                                            ((PubHolidayDetails.PubHolDate) = #" + dtCurrentDate.ToString("dd-MMM-yyyy") + "#) " + 
                                            " AND ((ClientMas.ClientID) = " + ClientID + ") " + 
                                        ");";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objPublicHolidayInfoList = JsonConvert.DeserializeObject<List<PublicHolidayInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objPublicHolidayInfoList;
        }

        public List<PublicHolidayInfo> getHolidayList(int ClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<PublicHolidayInfo> objPublicHolidayInfoList = new List<PublicHolidayInfo>();
            DataTable dt = new DataTable();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT " + 
                                        " PubHolidayDetails.PubHolDetID, " +
                                        " PublicHolidayMas.PubHolMasID, " +
                                        " PubHolidayDetails.PubHolidayTitle, " +
                                        " PubHolType.PubHolTypeTitle, " +
                                        " PubHolidayDetails.PubHolDate, " +
                                        " Format(PubHolDate, \"dddd\") AS DayName, " +
                                        " PubHolType.PubHolTypeID, " +
                                        " PubHolType.PubHolTypeTitle, " +
                                        " PublicHolidayMas.OrderID, " +
                                        " PubHolidayDetails.IsFestival, " +
                                        " ClientMas.ClientID " +
                                    " FROM " +
                                        " (ClientMas INNER JOIN PublicHolidayMas ON ClientMas.ClientID = PublicHolidayMas.ClientID) " +
                                        " INNER JOIN ( PubHolType INNER JOIN PubHolidayDetails ON PubHolType.PubHolTypeID = PubHolidayDetails.PubHolTypeID) " +
                                        " ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID " +
                                    " WHERE " +
                                        " ( " +
                                            "((PubHolidayDetails.PubHolDate) >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# AND (PubHolidayDetails.PubHolDate) <= #" + dtTo.ToString("dd-MMM-yyyy") + "#) " + 
                                            " AND ((ClientMas.ClientID) = " + ClientID + ") " +
                                        " ) " +
                                    " ORDER BY " + 
                                        " PubHolidayDetails.PubHolDetID, PublicHolidayMas.PubHolMasID, PubHolidayDetails.PubHolDate, PublicHolidayMas.OrderID;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objPublicHolidayInfoList = JsonConvert.DeserializeObject<List<PublicHolidayInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objPublicHolidayInfoList;
        }

        public List<PublicHolidayInfo> getNonFestivalHolidayList(int ClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<PublicHolidayInfo> objNonFestivalHolidayList = new List<PublicHolidayInfo>();
            DataTable dt = new DataTable();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT " +
                                        " PubHolidayDetails.PubHolDetID, " +
                                        " PublicHolidayMas.PubHolMasID, " +
                                        " PubHolidayDetails.PubHolDate, " +
                                        " PubHolType.PubHolTypeID, " +
                                        " PubHolType.PubHolTypeTitle, " +
                                        " PublicHolidayMas.OrderID, " +
                                        " PubHolidayDetails.IsFestival, " +
                                        " ClientMas.ClientID " +
                                    " FROM " +
                                        " (ClientMas INNER JOIN PublicHolidayMas ON ClientMas.ClientID = PublicHolidayMas.ClientID) " +
                                        " INNER JOIN ( PubHolType INNER JOIN PubHolidayDetails ON PubHolType.PubHolTypeID = PubHolidayDetails.PubHolTypeID) " +
                                        " ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID " +
                                    " WHERE " +
                                        " ( " +
                                            "((PubHolidayDetails.PubHolDate) >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# AND (PubHolidayDetails.PubHolDate) <= #" + dtTo.ToString("dd-MMM-yyyy") + "#) " +
                                            " AND ((ClientMas.ClientID) = " + ClientID + ") " +
                                            " AND ((PubHolidayDetails.IsFestival) = false) " +
                                        " ) " +
                                    " ORDER BY " +
                                        " PubHolidayDetails.PubHolDetID, PublicHolidayMas.PubHolMasID, PubHolidayDetails.PubHolDate, PublicHolidayMas.OrderID;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objNonFestivalHolidayList = JsonConvert.DeserializeObject<List<PublicHolidayInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objNonFestivalHolidayList;
        }

        public List<PublicHolidayInfo> getFestivalHolidayList(int ClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<PublicHolidayInfo> objFestivalHolidayList = new List<PublicHolidayInfo>();
            DataTable dt = new DataTable();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT " +
                                        " PubHolidayDetails.PubHolDetID, " +
                                        " PublicHolidayMas.PubHolMasID, " +
                                        " PubHolidayDetails.PubHolDate, " +
                                        " PubHolType.PubHolTypeID, " +
                                        " PubHolType.PubHolTypeTitle, " +
                                        " PublicHolidayMas.OrderID, " +
                                        " PubHolidayDetails.IsFestival, " +
                                        " ClientMas.ClientID " +
                                    " FROM " +
                                        " (ClientMas INNER JOIN PublicHolidayMas ON ClientMas.ClientID = PublicHolidayMas.ClientID) " +
                                        " INNER JOIN ( PubHolType INNER JOIN PubHolidayDetails ON PubHolType.PubHolTypeID = PubHolidayDetails.PubHolTypeID) " +
                                        " ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID " +
                                    " WHERE " +
                                        " ( " +
                                            "((PubHolidayDetails.PubHolDate) >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# AND (PubHolidayDetails.PubHolDate) <= #" + dtTo.ToString("dd-MMM-yyyy") + "#) " +
                                            " AND ((ClientMas.ClientID) = " + ClientID + ") " +
                                            " AND ((PubHolidayDetails.IsFestival) = true) " +
                                        " ) " +
                                    " ORDER BY " +
                                        " PubHolidayDetails.PubHolDetID, PublicHolidayMas.PubHolMasID, PubHolidayDetails.PubHolDate, PublicHolidayMas.OrderID;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objFestivalHolidayList = JsonConvert.DeserializeObject<List<PublicHolidayInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objFestivalHolidayList;
        }

        public List<PublicHolidayInfo> GetHolidayDetailsInfo(int txtYearID)
        {
            List<PublicHolidayInfo> lstPublicHolidayInfo = new List<PublicHolidayInfo>();

            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        "PubHolidayDetails.PubHolDetID, " + 
                                        "PubHolidayDetails.PubHolMasID, " + 
                                        "PubHolidayDetails.PubHolidayTitle, " + 
                                        "PubHolidayDetails.PubHolDate, " + 
                                        "PubHolidayDetails.OrderID, " +
                                        "PubHolidayDetails.IsFestival, " +
                                        "WeekdayName (Weekday ([PubHolDate], 0)) AS DayName " + 
                                    "FROM " + 
                                        "PubHolidayDetails " + 
                                    "WHERE " + 
                                        "(((PubHolidayDetails.PubHolMasID) = " + txtYearID + "));";

                strQuery = "SELECT " +
                                "PubHolidayDetails.PubHolDetID, " +
                                "PubHolidayDetails.PubHolMasID, " +
                                "PubHolidayDetails.PubHolidayTitle, " +
                                "PubHolidayDetails.PubHolDate, " +
                                "PubHolidayDetails.OrderID, " +
                                "PubHolidayDetails.IsFestival, " +
                                "WeekdayName (Weekday ([PubHolDate], 0)) AS DayName, " +
                                "ClientMas.ClientID " +
                            "FROM " +
                                "( " +
                                    "ClientMas " +
                                    "INNER JOIN PublicHolidayMas ON ClientMas.ClientID = PublicHolidayMas.ClientID " +
                                ") " +
                                "INNER JOIN PubHolidayDetails ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID " +
                            "WHERE " +
                                "(" +
                                    "((PubHolidayDetails.PubHolMasID) = " + txtYearID + ") " +
                                    "AND ((ClientMas.ClientID) = " + +CurrentUser.ClientID + ") " +
                                ");";

                strQuery = "SELECT " +
                                   " PubHolidayDetails.PubHolDetID, " +
                                   " PubHolidayDetails.PubHolMasID, " +
                                   " PubHolidayDetails.PubHolidayTitle, " +
                                   " PubHolidayDetails.PubHolDate, " +
                                   " PubHolType.PubHolTypeID, " +
                                   " PubHolType.PubHolTypeTitle, " +
                                   " PubHolidayDetails.OrderID, " +
                                   " PubHolidayDetails.IsFestival, " +
                                   " WeekdayName (Weekday ([PubHolDate], 0)) AS DayName, " +
                                   " ClientMas.ClientID " +
                                " FROM " +
                                    " PubHolType INNER JOIN (( ClientMas INNER JOIN PublicHolidayMas ON ClientMas.ClientID = PublicHolidayMas.ClientID) INNER JOIN PubHolidayDetails ON PublicHolidayMas.PubHolMasID = PubHolidayDetails.PubHolMasID ) " +
                                    " ON PubHolType.PubHolTypeID = PubHolidayDetails.PubHolTypeID " +
                                " WHERE " +
                                    " (((PubHolidayDetails.PubHolMasID) = " + txtYearID + ") AND ((ClientMas.ClientID) = " + CurrentUser.ClientID + "))";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                List<PublicHolidayInfo> objPublicHolidayInfo = JsonConvert.DeserializeObject<List<PublicHolidayInfo>>(DataTableToJSon);
                if (objPublicHolidayInfo.Count > 0)
                {
                    lstPublicHolidayInfo = objPublicHolidayInfo;
                    int minRecords = Math.Abs(lstPublicHolidayInfo.Count - 26);
                    for (int iDefaultRecord = 0; iDefaultRecord < minRecords; iDefaultRecord++)
                    {
                        lstPublicHolidayInfo.Add(new PublicHolidayInfo
                        {
                            PubHolDetID = 0,
                            PubHolMasID = txtYearID,
                            PubHolidayTitle = "",
                            PubHolDate = null,
                            OrderID = 0,
                            PubHolTypeID = 0,
                            PubHolTypeTitle = ""
                        });
                    }
                }
                else
                {
                    for (int iDefaultRecord = 0; iDefaultRecord < 26; iDefaultRecord++)
                    {
                        lstPublicHolidayInfo.Add(new PublicHolidayInfo
                        {
                            PubHolDetID = 0,
                            PubHolMasID = txtYearID,
                            PubHolidayTitle = "",
                            PubHolDate = null,
                            OrderID = 0,
                            PubHolTypeID = 0,
                            PubHolTypeTitle = ""
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return lstPublicHolidayInfo;
        }

        public int InsertPublicHolidayMasterInfo(string txtPublicHolidayYear, bool IsDefault, int txtOrderID, int txtFinYearID)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("PublicHolidayMas", "PubHolMasID");

                Response<int> OrderID = objGenFunc.getMaxRowCount("PublicHolidayMas", "OrderID");

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE PublicHolidayMas SET IsDefault = false";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;


                strQuery = "INSERT INTO PublicHolidayMas (PubHolMasID, PubHolYear, IsDefault, OrderID, FinYearID, ClientID) VALUES " +
                 "(" + maxRowCount.Data + ",'" + txtPublicHolidayYear + "'," + IsDefault + "," + OrderID.Data + "," + txtFinYearID + "," + CurrentUser.ClientID + ")";

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

        public int InsertPublicHolidayDetailInfo(int txtPubHolMasID, string txtPublicHolidayTitle, DateTime txtPublicHolidayDate, int txtPubHolTypeID, int txtOrderID, bool IsFestival)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("PubHolidayDetails", "PubHolDetID");

                Response<int> OrderID = objGenFunc.getMaxRowCount("PubHolidayDetails", "OrderID");

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO PubHolidayDetails (PubHolDetID, PubHolMasID, PubHolidayTitle, PubHolDate, PubHolTypeID, OrderID, IsFestival) VALUES " +
                 "(" + maxRowCount.Data + "," + txtPubHolMasID + ",'" + txtPublicHolidayTitle + "','" + txtPublicHolidayDate.ToString("dd-MM-yyyy") + "'," + txtPubHolTypeID + "," + OrderID.Data + "," + IsFestival + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

        public int UpdatePublicHolidayDetailInfo(int txtPubHolDetID, int txtPubHolMasID, string txtPublicHolidayTitle, DateTime txtPublicHolidayDate, int txtPubHolTypeID, int txtOrderID, bool IsFestival)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE PubHolidayDetails SET PubHolidayTitle = '" + txtPublicHolidayTitle + "', PubHolDate = '" + txtPublicHolidayDate.ToString("dd-MM-yyyy") + "', PubHolTypeID = " + txtPubHolTypeID + ", IsFestival = " + IsFestival + 
                 " WHERE PubHolDetID = " + txtPubHolDetID + "";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = txtPubHolDetID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

        public int DeletePublicHolidayDetailInfo(int txtPubHolDetID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "DELETE * FROM PubHolidayDetails " +
                 "WHERE PubHolDetID = " + txtPubHolDetID + "";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = txtPubHolDetID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

    }
}
