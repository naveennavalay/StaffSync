﻿using ModelStaffSync;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace dbStaffSync
{
    public class clsAssetsCategory
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset;
        clsGenFunc objGenFunc = new clsGenFunc();

        public DataTable getAssetsCategoryNamesList(int txtClientID)
        {
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM AssetCategoryMas WHERE IsActive = true AND IsDeleted = false AND ClientID = " + txtClientID + " ORDER BY AssetCatMasID ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return dt;
        }

        public DataTable getRecoveryTypeNamesList()
        {
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " RecoveryTypeMas.RecoveryTypeID, " + 
                                        " RecoveryTypeMas.RecoveryTypeCode, " + 
                                        " RecoveryTypeMas.RecoveryTypeName, " + 
                                        " RecoveryTypeMas.RecoveryTypeDescription, " + 
                                        " RecoveryTypeMas.IsActive, " + 
                                        " RecoveryTypeMas.IsDeleted " + 
                                    " FROM " + 
                                        " RecoveryTypeMas " + 
                                    " WHERE " + 
                                        " RecoveryTypeMas.IsActive = True " + 
                                        " AND RecoveryTypeMas.IsDeleted = False  " + 
                                    " ORDER BY " + 
                                        " RecoveryTypeMas.RecoveryTypeID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return dt;
        }

        public DataTable getCurrentStatusNamesList()
        {
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " CurrentAssetStatus.CurrentAssetStatusID, " + 
                                        " CurrentAssetStatus.CurrentAssetStatusCode, " + 
                                        " CurrentAssetStatus.CurrentAssetStatusName, " + 
                                        " CurrentAssetStatus.CurrentAssetDescription, " + 
                                        " CurrentAssetStatus.IsActive, " + 
                                        " CurrentAssetStatus.IsDeleted " + 
                                    " FROM " + 
                                        " CurrentAssetStatus " + 
                                    " WHERE " + 
                                            " CurrentAssetStatus.IsActive = True " + 
                                            " AND CurrentAssetStatus.IsDeleted = False " + 
                                    " ORDER BY " + 
                                        " CurrentAssetStatus.CurrentAssetStatusID ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return dt;
        }

        public List<AssetsCategory> getAssetsCategoryList(int txtClientID)
        {
            List<AssetsCategory> objAssetsCategoryList = new List<AssetsCategory>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM AssetCategoryMas WHERE IsActive = true AND IsDeleted = false AND ClientID = " + txtClientID + " ORDER BY AssetCatMasID ASC";
                strQuery = @"SELECT
                                    AssetCategoryMas.AssetCatMasID,
                                    AssetCategoryMas.AssetCode,
                                    IIf(
                                        AssetCategoryMas.ParentAssetCatMasID = 1,
                                        AssetCategoryMas.AssetName,
                                        ""-----"" & AssetCategoryMas.AssetName
                                    ) AS AssetName,
                                    AssetCategoryMas.AssetDescription,
                                    AssetCategoryMas_1.AssetName AS ParentCatMasName,
                                    AssetCategoryMas.ParentAssetCatMasID,
                                    AssetCategoryMas.IsActive,
                                    AssetCategoryMas.IsDeleted
                                FROM
                                    AssetCategoryMas
                                    LEFT JOIN AssetCategoryMas AS AssetCategoryMas_1 ON AssetCategoryMas.ParentAssetCatMasID = AssetCategoryMas_1.AssetCatMasID
                                WHERE
                                    (
                                        ((AssetCategoryMas.ClientID) = " + txtClientID + @")
                                        AND ((AssetCategoryMas.IsActive) = True)
                                        AND ((AssetCategoryMas.IsDeleted) = False)
                                    )
                                ORDER BY
                                    IIf(
                                        AssetCategoryMas.ParentAssetCatMasID = 1,
                                        AssetCategoryMas.AssetCatMasID,
                                        AssetCategoryMas.ParentAssetCatMasID
                                    ),
                                    IIf(AssetCategoryMas.ParentAssetCatMasID = 1, 0, 1),
                                    AssetCategoryMas.AssetCatMasID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAssetsCategoryList = JsonConvert.DeserializeObject<List<AssetsCategory>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objAssetsCategoryList;
        }

        public AssetsCategory getAssetsCategoryInfo(int txtAssetCatMasID, int txtClient)
        {
            AssetsCategory objAssetsCategoryInfo = new AssetsCategory();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM AssetCategoryMas WHERE AssetCatMasID = " + txtAssetCatMasID + " AND ClientID = " + txtClient + " AND IsActive = true AND IsDeleted = false ORDER BY AssetCatMasID ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAssetsCategoryInfo = JsonConvert.DeserializeObject<AssetsCategory>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objAssetsCategoryInfo;
        }

        public AssetsCategory getAssetsCategoryInfo(string txtAssetName, int txtClient)
        {
            AssetsCategory objAssetsCategoryInfo = new AssetsCategory();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM AssetCategoryMas WHERE AssetName = '" + txtAssetName + "' AND ClientID = " + txtClient + " AND IsActive = true AND IsDeleted = false ORDER BY AssetCatMasID ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAssetsCategoryInfo = JsonConvert.DeserializeObject<AssetsCategory>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objAssetsCategoryInfo;
        }

        public List<AssetsCategory> getAssetsCategoryInfoFilter(string txtAssetName, int txtClientID)
        {
            List<AssetsCategory> objAssetsCategoryList = new List<AssetsCategory>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " +
                        " AssetCategoryMas.AssetCatMasID, " +
                        " AssetCategoryMas.AssetCode, " +
                        " AssetCategoryMas.AssetName, " +
                        " AssetCategoryMas.AssetDescription, " +
                        " AssetCategoryMas.IsActive, " +
                        " AssetCategoryMas.IsDeleted, " +
                        " AssetCategoryMas.AssetNote, " +
                        " AssetCategoryMas.ClientID " +
                    " FROM " +
                        " AssetCategoryMas " +
                    " WHERE " +
                        " AssetCategoryMas.AssetName LIKE '%" + txtAssetName + "%' AND IsActive = true and IsDeleted = false AND ClientiD = " + txtClientID + " ORDER BY AssetCatMasID ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAssetsCategoryList = JsonConvert.DeserializeObject<List<AssetsCategory>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objAssetsCategoryList;
        }

        public int GetAssetsCategoryInfoByName(string AssetName)
        {
            int selectedAssetID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT AssetCatMasID FROM AssetCategoryMas WHERE AssetName = '" + AssetName + "'";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;

                cmd.Parameters.AddWithValue("@AssetName", AssetName.Trim());
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    selectedAssetID = Convert.ToInt32(result);
                }
                else
                {
                    selectedAssetID = 0;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedAssetID;
        }


        public int InsertAssetCategoryInfo(string txtAssetCode, string txtAssetName, string txtAssetDescription, string txtAssetNote, int ParentAssetCatMasID, bool IsActive, bool IsDeleted, int txtClientID)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("AssetCategoryMas", "AssetCatMasID");

                ParentAssetCatMasID = (ParentAssetCatMasID == 0) ? 1 : ParentAssetCatMasID;

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO AssetCategoryMas (AssetCatMasID, AssetCode, AssetName, AssetDescription, AssetNote, ParentAssetCatMasID, IsActive, IsDeleted, ClientID) VALUES " +
                 "(" + maxRowCount.Data + ",'" + "ACC-" + (maxRowCount.Data).ToString().PadLeft(4, '0').Trim() + "', '" + txtAssetName + "', '" + txtAssetDescription + "','" + txtAssetNote + "'," + ParentAssetCatMasID + ", " + IsActive + ", " + IsDeleted + ", " + txtClientID + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateAssetCategoryInfo(int intAssetCatMasID, string txtAssetCode, string txtAssetName, string txtAssetDescription, string txtAssetNote, int ParentAssetCatMasID, bool IsActive, bool IsDeleted, int txtClientID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE AssetCategoryMas SET " + 
                                        " AssetCode = '" + txtAssetCode + "', AssetName = '" + txtAssetName + "', AssetDescription = '" + txtAssetDescription + "', ParentAssetCatMasID = " + ParentAssetCatMasID + ", IsActive = " + IsActive + ", AssetNote = '" + txtAssetNote + "', ClientID = " + txtClientID + 
                                  " WHERE " +
                                        " AssetCatMasID = " + intAssetCatMasID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = intAssetCatMasID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int DeleteAssetCategoryInfo(int intAssetCatMasID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "DELETE * FROM AssetCategoryMas " +
                                  " WHERE " +
                                        " AssetCatMasID = " + intAssetCatMasID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = intAssetCatMasID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }
    }
}
