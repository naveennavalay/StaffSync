﻿using ModelStaffSync;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace dbStaffSync
{
    public class clsDashboardChartWidgets
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset;
        clsGenFunc objGenFunc = new clsGenFunc();

        public List<LeaveStatusSummary> getLeaveStatusSummaryChartData(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<LeaveStatusSummary> objLeaveStatusSummaryList = new List<LeaveStatusSummary>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                //" EmpLeaveTransMas.LeaveApprovalComments AS LeaveApprovalComments, " + 
                //" EmpLeaveTransMas.Canceled AS Canceled," +
                string strQuery = "SELECT " +
                                        " Format(EmpLeaveTransMas.ActualLeaveDateFrom, 'mmm-yyyy') AS MonthName, " + 
                                        " Year(EmpLeaveTransMas.ActualLeaveDateFrom) AS LeaveYear, " + 
                                        " Month(EmpLeaveTransMas.ActualLeaveDateFrom) AS LeaveMonth, " + 
                                        " Count(EmpLeaveTransMas.OrderID) AS TotalApplication, " + 
                                        " Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Approved :%', 1, 0)) AS TotalApproved, " + 
                                        " Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Rejected :%' AND EmpLeaveTransMas.LeaveRejectionComments LIKE 'Rejected :%' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalRejected, " + 
                                        " Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments = 'Not yet Approved' AND EmpLeaveTransMas.LeaveRejectionComments = 'Not yet Rejected' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalPending, " +  
                                        " Sum(IIf(EmpLeaveTransMas.Canceled = True, 1, 0)) AS TotalCancelled, " + 
                                        " Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Approved :%' AND EmpLeaveTransMas.Canceled = False, IIf(IsNull(EmpLeaveTransMas.LeaveDuration), 0, EmpLeaveTransMas.LeaveDuration), 0)) AS TotalLeaveDays " + 
                                    " FROM " + 
                                        " ClientMas INNER JOIN (EmpMas INNER JOIN EmpLeaveTransMas ON EmpMas.EmpID = EmpLeaveTransMas.EmpID) ON ClientMas.ClientID = EmpMas.ClientID " + 
                                    " WHERE " + 
                                        " ClientMas.ClientID = " + txtClientID + 
                                        " AND EmpMas.IsActive = True " + 
                                        " AND EmpMas.IsDeleted = False " +
                                        " AND ((EmpLeaveTransMas.ActualLeaveDateFrom) >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# AND (EmpLeaveTransMas.ActualLeaveDateFrom) < #" + dtTo.ToString("dd-MMM-yyyy") + "#) " +
                                    " GROUP BY " + 
                                        " Format(EmpLeaveTransMas.ActualLeaveDateFrom, 'mmm-yyyy'), " + 
                                        " Year(EmpLeaveTransMas.ActualLeaveDateFrom), " + 
                                        " Month(EmpLeaveTransMas.ActualLeaveDateFrom) " + 
                                    " ORDER BY " + 
                                        " Year(EmpLeaveTransMas.ActualLeaveDateFrom), " + 
                                        " Month(EmpLeaveTransMas.ActualLeaveDateFrom);";
                strQuery = @"SELECT
                                Format(EmpLeaveTransMas.ActualLeaveDateFrom, 'mmm-yyyy') AS MonthName,
                                Year(EmpLeaveTransMas.ActualLeaveDateFrom) AS LeaveYear,
                                Month(EmpLeaveTransMas.ActualLeaveDateFrom) AS LeaveMonth,
                                Count(EmpLeaveTransMas.OrderID) AS TotalApplication,
                                Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Approved :%', 1, 0)) AS TotalApproved,
                                Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Rejected :%' AND EmpLeaveTransMas.LeaveRejectionComments LIKE 'Rejected :%' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalRejected,
                                Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments = 'Not yet Approved' AND EmpLeaveTransMas.LeaveRejectionComments = 'Not yet Rejected' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalPending,
                                Sum(IIf(EmpLeaveTransMas.Canceled = True, 1, 0)) AS TotalCancelled,
                                Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Approved :%' AND EmpLeaveTransMas.Canceled = False, IIf( IsNull(EmpLeaveTransMas.LeaveDuration), 0, EmpLeaveTransMas.LeaveDuration), 0)) AS TotalLeaveDays
                            FROM
                                (
                                    (
                                        ClientMas
                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                    )
                                    INNER JOIN EmpLeaveTransMas ON EmpMas.EmpID = EmpLeaveTransMas.EmpID
                                )
                                INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                            WHERE
                                (
                                    ((ClientMas.ClientID) = " + txtClientID + @")
                                    AND ((EmpMas.IsActive) = True)
                                    AND ((EmpMas.IsDeleted) = False)
                                    AND (
                                        (EmpLeaveTransMas.ActualLeaveDateFrom) >= #" + dtFrom.Date.ToString("dd-MMM-yyyy") + @"#
                                        AND (EmpLeaveTransMas.ActualLeaveDateFrom) < #" + dtTo.Date.ToString("dd-MMM-yyyy") + @"#
                                    )
                                )
                            GROUP BY
                                Format(EmpLeaveTransMas.ActualLeaveDateFrom, 'mmm-yyyy'),
                                Year(EmpLeaveTransMas.ActualLeaveDateFrom),
                                Month(EmpLeaveTransMas.ActualLeaveDateFrom),
                                EmpMas.ResignedStatus,
                                PersonalInfoMas.GoldProfile
                            HAVING
                                (
                                    ((EmpMas.ResignedStatus) = False)
                                    AND ((PersonalInfoMas.GoldProfile) = False)
                                )
                            ORDER BY
                                Year(EmpLeaveTransMas.ActualLeaveDateFrom),
                                Month(EmpLeaveTransMas.ActualLeaveDateFrom);";

                //" EmpLeaveTransMas.LeaveApprovalComments, " +
                //" EmpLeaveTransMas.Canceled, " +
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                //cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objLeaveStatusSummaryList = JsonConvert.DeserializeObject<List<LeaveStatusSummary>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objLeaveStatusSummaryList;
        }

        public List<EmployeesLeaveTodayChartData> GetEmployeesWhoAreOnLeaveToday(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<EmployeesLeaveTodayChartData> objEmployeesLeaveTodayChartDataList = new List<EmployeesLeaveTodayChartData>();

            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        LeaveTypeMas.LeaveTypeTitle,
                                        EmpLeaveTransMas.ActualLeaveDateFrom AS LeaveDate,
                                        EmpLeaveTransMas.LeaveApprovalComments,
                                        ClientMas.ClientID,
                                        EmpDailyAttendanceInfo.LeaveTRID,
                                        EmpMas.ResignedStatus,
                                        PersonalInfoMas.GoldProfile
                                    FROM
                                        (
                                            LeaveTypeMas
                                            INNER JOIN (
                                                (
                                                    DesigMas
                                                    INNER JOIN (
                                                        DepMas
                                                        INNER JOIN (
                                                            ClientMas
                                                            INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                        ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                    ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                                )
                                                INNER JOIN (
                                                    EmpLeaveTransMas
                                                    INNER JOIN EmpDailyAttendanceInfo ON EmpLeaveTransMas.LeaveTRID = EmpDailyAttendanceInfo.LeaveTRID
                                                ) ON (EmpMas.EmpID = EmpLeaveTransMas.EmpID)
                                                AND (EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID)
                                            ) ON LeaveTypeMas.LeaveTypeID = EmpLeaveTransMas.LeaveTypeID
                                        )
                                        INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                    WHERE
                                        (
                                            ((EmpMas.EmpID) > 1)
                                            AND ((EmpLeaveTransMas.ActualLeaveDateFrom) = Date())
                                            AND ((ClientMas.ClientID) = " + txtClientID + @")
                                            AND ((EmpDailyAttendanceInfo.LeaveTRID) > 0)
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND ((EmpMas.ResignedStatus) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                            AND ((EmpLeaveTransMas.Canceled) = False)
                                        )
                                    ORDER BY
                                        EmpMas.EmpID,
                                        EmpMas.EmpName;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeesLeaveTodayChartDataList = JsonConvert.DeserializeObject<List<EmployeesLeaveTodayChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objEmployeesLeaveTodayChartDataList;
        }

        public List<LeaveMatrixChartData> GetLeaveMatrixChartData(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<LeaveMatrixChartData> objLeaveMatrixList = new List<LeaveMatrixChartData>();

            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        DepMas.DepartmentTitle AS Department,
                                        Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Approved :%' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalApproved,
                                        Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments = 'Not yet Approved' AND EmpLeaveTransMas.LeaveRejectionComments = 'Not yet Rejected' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalPending,
                                        Sum(IIf(EmpLeaveTransMas.LeaveApprovalComments LIKE 'Rejected :%' AND EmpLeaveTransMas.LeaveRejectionComments LIKE 'Rejected :%' AND EmpLeaveTransMas.Canceled = False, 1, 0)) AS TotalRejected,
                                        Sum(IIf(EmpLeaveTransMas.Canceled = True, 1, 0)) AS TotalCancelled,
                                        EmpMas.ResignedStatus,
                                        PersonalInfoMas.GoldProfile
                                    FROM
                                        (
                                            (
                                                DepMas
                                                INNER JOIN (
                                                    ClientMas
                                                    INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                            )
                                            INNER JOIN EmpLeaveTransMas ON EmpMas.EmpID = EmpLeaveTransMas.EmpID
                                        )
                                        INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                    WHERE
                                        (
                                            ((ClientMas.ClientID) = " + txtClientID + @")
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND (
                                                (EmpLeaveTransMas.ActualLeaveDateFrom) >= #" + dtFrom.Date.ToString("dd-MMM-yyyy") + @"#
                                                AND (EmpLeaveTransMas.ActualLeaveDateFrom) < #" + dtTo.Date.ToString("dd-MMM-yyyy") + @"#
                                            )
                                        )
                                    GROUP BY
                                        DepMas.DepartmentTitle,
                                        EmpMas.ResignedStatus,
                                        PersonalInfoMas.GoldProfile
                                    HAVING
                                        (
                                            ((EmpMas.ResignedStatus) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                        )
                                    ORDER BY
                                        DepMas.DepartmentTitle;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objLeaveMatrixList = JsonConvert.DeserializeObject<List<LeaveMatrixChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objLeaveMatrixList;
        }

        public List<UpcomingHolidayChartData> GetUpcomingHolidayChartData(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<UpcomingHolidayChartData> objUpcomingHolidayList = new List<UpcomingHolidayChartData>();

            DataTable dt = new DataTable();

            OleDbConnection conn = null;

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                    "PubHolidayDetails.PubHolidayTitle AS HolidayName, " + 
                    "PubHolidayDetails.PubHolDate AS HolidayDate, " +
                    "DateDiff(" + "\"d\", " + "Date(), " + "PubHolidayDetails.PubHolDate" + ") AS DaysRemaining " +
                    "FROM " +
                    "PublicHolidayMas " +
                    "INNER JOIN PubHolidayDetails ON PublicHolidayMas.PubHolMasID = " +
                    "PubHolidayDetails.PubHolMasID " +
                    "WHERE " +
                    "PublicHolidayMas.ClientID = " + txtClientID +
                    " AND PubHolidayDetails.PubHolDate >= Date()" +
                    " AND PubHolidayDetails.PubHolDate < #" + dtTo.ToString("dd-MMM-yyyy") + "# " +
                    "ORDER BY " +
                    "PubHolidayDetails.PubHolDate ASC";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objUpcomingHolidayList = JsonConvert.DeserializeObject<List<UpcomingHolidayChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objUpcomingHolidayList;
        }

        public List<AttendanceSummaryChartData> getAttendanceDepartmentChartData(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            List<AttendanceSummaryChartData> objAttendanceSummaryChartData = new List<AttendanceSummaryChartData>();

            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();


                string strQuery =
                    "SELECT " +

                    "DepMas.DepartmentTitle AS Department, " +

                    "Sum(" +
                        "IIf(" +
                            "EmpDailyAttendanceInfo.AttStatus = 'Present', " +
                            "1, " +
                            "0" +
                        ")" +
                    ") AS TotalPresent, " +

                    "Sum(" +
                        "IIf(" +
                            "EmpDailyAttendanceInfo.AttStatus = 'Leave : Full Day', " +
                            "1, " +
                            "IIf(" +
                                "EmpDailyAttendanceInfo.AttStatus = 'Leave : First Half' " +
                                "OR " +
                                "EmpDailyAttendanceInfo.AttStatus = 'Leave : Second Half', " +
                                "0.5, " +
                                "0" +
                            ")" +
                        ")" +
                    ") AS TotalLeave, " +

                    "Sum(" +
                        "IIf(" +
                            "EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay', " +
                            "1, " +
                            "IIf(" +
                                "EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : First Half' " +
                                "OR " +
                                "EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : Second Half', " +
                                "0.5, " +
                                "0" +
                            ")" +
                        ")" +
                    ") AS TotalLOP " +

                    "FROM " +

                    "ClientMas " +

                    "INNER JOIN " +
                    "( " +

                        "DepMas " +

                        "INNER JOIN " +
                        "( " +

                            "EmpMas " +

                            "INNER JOIN EmpDailyAttendanceInfo " +
                            "ON EmpMas.EmpID = " +
                            "EmpDailyAttendanceInfo.EmpID " +

                        ") " +

                        "ON DepMas.DepartmentID = " +
                        "EmpMas.DepartmentID " +

                    ") " +

                    "ON ClientMas.ClientID = " +
                    "EmpMas.ClientID " +

                    "WHERE " +

                    "ClientMas.ClientID = " +
                    txtClientID + " " +

                    "AND EmpMas.IsActive = True " +

                    "AND EmpMas.IsDeleted = False " +

                    "AND EmpDailyAttendanceInfo.AttDate >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# " +

                    "AND EmpDailyAttendanceInfo.AttDate < #" +
                    dtTo.ToString("dd-MMM-yyyy") +
                    "# " +

                    "GROUP BY " +
                    "DepMas.DepartmentTitle " +

                    "ORDER BY " +
                    "DepMas.DepartmentTitle;";


                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAttendanceSummaryChartData = JsonConvert.DeserializeObject<List<AttendanceSummaryChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                conn =
                    dbStaffSync.closeDBConnection();
            }


            return objAttendanceSummaryChartData;
        }

        public AttendanceCalendarChartResponse getAttendanceCalendarChartData(int txtClientID, DateTime dtFrom, DateTime dtTo)
        {
            AttendanceCalendarChartResponse response = new AttendanceCalendarChartResponse();

            try
            {
                conn = dbStaffSync.openDBConnection();

                // ============================================================
                // LEVEL 1
                // MONTH-WISE
                // ============================================================

                string strMonthQuery = "SELECT " + 
                                                "Q.AttendanceMonth, " +
                                                "Sum(IIf(Q.StatusType = 'Present', 1, 0)) AS TotalPresent, " +
                                                "Sum(IIf(Q.StatusType = 'Leave', 1, 0)) AS TotalLeave, " +
                                                "Sum(IIf(Q.StatusType = 'Loss Of Pay', 1, 0)) AS TotalLOP " +
                                            "FROM " +
                                                " ( " + 
                                                    "SELECT DISTINCT " + 
                                                        "Format(EmpDailyAttendanceInfo.AttDate,'mmm-yyyy') AS AttendanceMonth, " + 
                                                        "EmpDailyAttendanceInfo.EmpID, " + 
                                                        "IIf(EmpDailyAttendanceInfo.AttStatus = 'Present', 'Present', " + 
                                                            "IIf(EmpDailyAttendanceInfo.AttStatus = 'Leave : Full Day' OR EmpDailyAttendanceInfo.AttStatus = 'Leave : First Half' OR EmpDailyAttendanceInfo.AttStatus = 'Leave : Second Half', 'Leave', " + 
                                                                "IIf(EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay' " + 
                                                                    "OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : First Half' " + 
                                                                    "OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : Second Half', " + 
                                                                    "'Loss Of Pay', " + 
                                                                    "'Other' " + 
                                                                ") " + 
                                                            ") " + 
                                                        ") AS StatusType " + 
                                                    "FROM " + 
                                                        "(" + 
                                                            "ClientMas " + 
                                                            "INNER JOIN EmpMas " + 
                                                                "ON ClientMas.ClientID = EmpMas.ClientID " + 
                                                        ") " + 
                                                        "INNER JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID " + 
                                                    "WHERE " + 
                                                        "ClientMas.ClientID = " + txtClientID +
                                                        "AND EmpMas.IsActive = True " + 
                                                        "AND EmpMas.IsDeleted = False " + 
                                                        "AND EmpDailyAttendanceInfo.AttDate >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# " + 
                                                        "AND EmpDailyAttendanceInfo.AttDate < #" + dtTo.ToString("dd-MMM-yyyy") + "# " + 
                                                ") AS Q " + 
                                            " WHERE " + 
                                                " Q.StatusType <> 'Other' " + 
                                            " GROUP BY " + 
                                                " Q.AttendanceMonth " + 
                                            " ORDER BY " + 
                                                "Q.AttendanceMonth;";

                OleDbCommand cmdMonth = conn.CreateCommand();

                cmdMonth.CommandType = CommandType.Text;
                cmdMonth.CommandText = strMonthQuery;

                OleDbDataAdapter daMonth =
                    new OleDbDataAdapter(cmdMonth);

                DataTable dtMonth = new DataTable();

                daMonth.Fill(dtMonth);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dtMonth);
                response.MonthData = JsonConvert.DeserializeObject<List<AttendanceCalendarMonthData>>(DataTableToJSon);

                //foreach (DataRow row in dtMonth.Rows)
                //{
                //    AttendanceCalendarChartData obj =
                //        new AttendanceCalendarChartData();

                //    obj.AttendanceMonth =
                //        Convert.ToString(row["AttendanceMonth"]);

                //    obj.TotalPresent =
                //        Convert.ToDouble(row["TotalPresent"]);

                //    obj.TotalLeave =
                //        Convert.ToDouble(row["TotalLeave"]);

                //    obj.TotalLOP =
                //        Convert.ToDouble(row["TotalLOP"]);

                //    CalculateAttendancePercentage(obj);

                //    response.MonthData.Add(obj);
                //}

                // ============================================================
                // LEVEL 2
                // DATE-WISE
                // ============================================================

                string strDateQuery ="SELECT " + 
                                            " Q.AttendanceDate, " +
                                            " Sum(IIf(Q.StatusType = 'Present', 1, 0)) AS TotalPresent, " +
                                            " Sum(IIf(Q.StatusType = 'Leave', 1, 0)) AS TotalLeave, " +
                                            " Sum(IIf(Q.StatusType = 'Loss Of Pay', 1, 0)) AS TotalLOP " +
                                        " FROM " +
                                            " (" +
                                                " SELECT DISTINCT " +
                                                    " EmpDailyAttendanceInfo.AttDate AS AttendanceDate, " +
                                                    " EmpDailyAttendanceInfo.EmpID, " +
                                                    " IIf(" +
                                                        " EmpDailyAttendanceInfo.AttStatus = 'Present', " +
                                                        " 'Present', " +
                                                        " IIf(" + 
                                                            " EmpDailyAttendanceInfo.AttStatus = 'Leave : Full Day' " + 
                                                            " OR EmpDailyAttendanceInfo.AttStatus = 'Leave : First Half' " + 
                                                            " OR EmpDailyAttendanceInfo.AttStatus = 'Leave : Second Half', " + 
                                                            " 'Leave', " + 
                                                            " IIf(" + 
                                                                " EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay' " + 
                                                                " OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : First Half' " + 
                                                                " OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : Second Half', " + 
                                                                " 'Loss Of Pay', " + 
                                                                " 'Other' " + 
                                                            ") " + 
                                                        ") " + 
                                                    ") AS StatusType " +
                                                " FROM " +
                                                    " (" +
                                                        " ClientMas INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID " +
                                                    " ) " +
                                                    " INNER JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID " +
                                                " WHERE " +
                                                        "ClientMas.ClientID = " + txtClientID +
                                                        "AND EmpMas.IsActive = True " +
                                                        "AND EmpMas.IsDeleted = False " +
                                                        "AND EmpDailyAttendanceInfo.AttDate >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# " +
                                                        "AND EmpDailyAttendanceInfo.AttDate < #" + dtTo.ToString("dd-MMM-yyyy") + "# " +
                                            " ) AS Q " +
                                        " WHERE " +
                                            " Q.StatusType <> 'Other' " +
                                        " GROUP BY " +
                                            " Q.AttendanceDate " +
                                        " ORDER BY " +
                                            " Q.AttendanceDate;";

                OleDbCommand cmdDate = conn.CreateCommand();

                cmdDate.CommandType = CommandType.Text;
                cmdDate.CommandText = strDateQuery;

                OleDbDataAdapter daDate = new OleDbDataAdapter(cmdDate);

                DataTable dtDate = new DataTable();
                daDate.Fill(dtDate);

                DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dtDate);
                response.DateData = JsonConvert.DeserializeObject<List<AttendanceCalendarDateData>>(DataTableToJSon);

                //foreach (DataRow row in dtDate.Rows)
                //{
                //    AttendanceCalendarChartData obj = new AttendanceCalendarChartData();

                //    DateTime attendanceDate = Convert.ToDateTime(row["AttendanceDate"]);

                //    //obj.AttendanceDate = attendanceDate.ToString("yyyy-MM-dd");

                //    obj.TotalPresent = Convert.ToDouble(row["TotalPresent"]);

                //    obj.TotalLeave = Convert.ToDouble(row["TotalLeave"]);

                //    obj.TotalLOP = Convert.ToDouble(row["TotalLOP"]);

                //    CalculateAttendancePercentage(obj);

                //    response.DateData.Add(obj);
                //}


                // ============================================================
                // LEVEL 3
                // DATE + DEPARTMENT
                // ============================================================

                string strDepartmentQuery =
                    "SELECT " + 
                            " Q.AttendanceDate, " + 
                            " Q.Department, " + 
                            " Sum(IIf(Q.StatusType = 'Present', 1, 0)) AS TotalPresent, " + 
                            " Sum(IIf(Q.StatusType = 'Leave', 1, 0)) AS TotalLeave, " + 
                            " Sum(IIf(Q.StatusType = 'Loss Of Pay', 1, 0)) AS TotalLOP " + 
                        " FROM " + 
                            "(" + 
                                "SELECT DISTINCT " + 
                                    " EmpDailyAttendanceInfo.AttDate AS AttendanceDate, " + 
                                    " DepMas.DepartmentTitle AS Department, " + 
                                    " EmpDailyAttendanceInfo.EmpID, " + 
                                    " IIf(EmpDailyAttendanceInfo.AttStatus = 'Present', 'Present', " + 
                                        " IIf(" + 
                                            " EmpDailyAttendanceInfo.AttStatus = 'Leave : Full Day' " + 
                                            " OR EmpDailyAttendanceInfo.AttStatus = 'Leave : First Half' " + 
                                            " OR EmpDailyAttendanceInfo.AttStatus = 'Leave : Second Half', " + 
                                            " 'Leave', " + 
                                            " IIf(" + 
                                                " EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay' " + 
                                                " OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : First Half' " + 
                                                " OR EmpDailyAttendanceInfo.AttStatus = 'Loss Of Pay : Second Half', " + 
                                                " 'Loss Of Pay', " + 
                                                "'Other' " + 
                                            " ) " +
                                        " ) " +
                                    " ) AS StatusType " +
                                " FROM " +
                                    " (" + 
                                      " (" + 
                                            "ClientMas INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID " + 
                                        ") " + 
                                        " INNER JOIN DepMas ON EmpMas.DepartmentID = DepMas.DepartmentID " + 
                                    ") " + 
                                    " INNER JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID " + 
                                " WHERE " +
                                        "ClientMas.ClientID = " + txtClientID +
                                        "AND EmpMas.IsActive = True " +
                                        "AND EmpMas.IsDeleted = False " +
                                        "AND EmpDailyAttendanceInfo.AttDate >= #" + dtFrom.ToString("dd-MMM-yyyy") + "# " +
                                        "AND EmpDailyAttendanceInfo.AttDate < #" + dtTo.ToString("dd-MMM-yyyy") + "# " + ") AS Q " + 
                        " WHERE " + 
                            " Q.StatusType <> 'Other' " + 
                        " GROUP BY " + 
                            " Q.AttendanceDate, " + 
                            " Q.Department " + 
                        " ORDER BY " + 
                            " Q.AttendanceDate, " + 
                            " Q.Department;";

                OleDbCommand cmdDepartment = conn.CreateCommand();

                cmdDepartment.CommandType = CommandType.Text;
                cmdDepartment.CommandText = strDepartmentQuery;

                OleDbDataAdapter daDepartment = new OleDbDataAdapter(cmdDepartment);

                DataTable dtDepartment = new DataTable();

                daDepartment.Fill(dtDepartment);

                DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dtDepartment);
                response.DepartmentData = JsonConvert.DeserializeObject<List<AttendanceCalendarDepartmentData>>(DataTableToJSon);

                //foreach (DataRow row in dtDepartment.Rows)
                //{
                //    AttendanceCalendarChartData obj =
                //        new AttendanceCalendarChartData();

                //    DateTime attendanceDate =
                //        Convert.ToDateTime(row["AttendanceDate"]);

                //    obj.AttendanceDate =
                //        attendanceDate.ToString("yyyy-MM-dd");

                //    obj.Department =
                //        Convert.ToString(row["Department"]);

                //    obj.TotalPresent =
                //        Convert.ToDouble(row["TotalPresent"]);

                //    obj.TotalLeave =
                //        Convert.ToDouble(row["TotalLeave"]);

                //    obj.TotalLOP =
                //        Convert.ToDouble(row["TotalLOP"]);

                //    CalculateAttendancePercentage(obj);

                //    response.DepartmentData.Add(obj);
                //}
            }
            catch (Exception ex)
            {
                // Log if required
                // MessageBox.Show(ex.Message);
            }
            finally
            {
                dbStaffSync.closeDBConnection();
            }

            return response;
        }

        private void CalculateAttendancePercentage(AttendanceCalendarChartData obj)
        {
            double total = obj.TotalPresent + obj.TotalLeave + obj.TotalLOP;

            if (total <= 0)
            {
                obj.PresentPercentage = 0;
                obj.LeavePercentage = 0;
                obj.LOPPercentage = 0;
                return;
            }

            obj.PresentPercentage = Math.Round((obj.TotalPresent / total) * 100, 2);

            obj.LeavePercentage = Math.Round((obj.TotalLeave / total) * 100, 2);

            obj.LOPPercentage = Math.Round((obj.TotalLOP / total) * 100, 2);
        }

        public List<LeaveInfoDepartmentInfoChartData> GetLeaveUtilisationDepartmentInfo(int txtClientID, DateTime dtTillDate)
        {
            List<LeaveInfoDepartmentInfoChartData> objLeaveInfoDepartmentInfoChartData = new List<LeaveInfoDepartmentInfoChartData>();

            DataTable dt = new DataTable();

            OleDbConnection conn = null;

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM qryDepWiseDBChart WHERE ClientID = " + txtClientID + " AND EffectiveDate <= #" + dtTillDate.ToString("yyyy-MM-dd") + "#;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objLeaveInfoDepartmentInfoChartData = JsonConvert.DeserializeObject<List<LeaveInfoDepartmentInfoChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objLeaveInfoDepartmentInfoChartData;
        }

        public List<LeaveInfoEmpWiseChartData> GetEmpWiseLeaveUtilisationInfo(int txtClientID, int txtDepartmentID, DateTime dtTillDate)
        {
            List<LeaveInfoEmpWiseChartData> objLeaveInfoEmpWiseChartData = new List<LeaveInfoEmpWiseChartData>();

            DataTable dt = new DataTable();

            OleDbConnection conn = null;

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT TOP 3 * FROM qryEmpWiseDBChart WHERE ClientID = " + txtClientID + " AND DepartmentID = " + txtDepartmentID + " AND EffectiveDate <= #" + dtTillDate.ToString("yyyy-MM-dd") + "# ORDER BY TotalLeaveBalance DESC;";
                strQuery = "SELECT TOP 3 " + 
                                    " EmpID, EmpName, DepartmentID, TotalLeaveAllotted, TotalLeaveAvailed, TotalLeaveBalance, 'Highest Balance' AS BalanceCategory " +
                                " FROM " +
                                    " qryEmpWiseDBChart " +
                                " WHERE " +
                                    " ClientID = " + txtClientID +
                                    " AND DepartmentID = " + txtDepartmentID +
                                    " AND EffectiveDate <= #" + dtTillDate.ToString("yyyy-MM-dd") + "# " +
                                " ORDER BY " +
                                    " TotalLeaveBalance DESC, EmpID Asc " +
                                " UNION ALL " +
                                " SELECT TOP 3 " +
                                    " EmpID, EmpName, DepartmentID, TotalLeaveAllotted, TotalLeaveAvailed, TotalLeaveBalance, 'Lowest Balance' AS BalanceCategory " +
                                " FROM " +
                                    " qryEmpWiseDBChart " +
                                " WHERE " +
                                    " ClientID = " + txtClientID +
                                    " AND DepartmentID = " + txtDepartmentID +
                                    " AND EffectiveDate <= #" + dtTillDate.ToString("yyyy-MM-dd") + "# " +
                                    " AND TotalLeaveBalance > 0 " +
                                " ORDER BY " +
                                    " TotalLeaveBalance ASC, EmpID Asc " +
                                " UNION ALL " +
                                " SELECT TOP 3 " +
                                    " EmpID, EmpName, DepartmentID, TotalLeaveAllotted, TotalLeaveAvailed, TotalLeaveBalance, 'Zero Balance' AS BalanceCategory " +
                                " FROM " +
                                    " qryEmpWiseDBChart " +
                                " WHERE " +
                                    " ClientID = " + txtClientID +
                                    " AND DepartmentID = " + txtDepartmentID +
                                    " AND EffectiveDate <= #" + dtTillDate.ToString("yyyy-MM-dd") + "# " +
                                    " AND TotalLeaveBalance = 0 " +
                                " ORDER BY " +
                                    " EmpID ASC;";

                strQuery = "SELECT " + 
                                " EmpID, " + 
                                " EmpName, " + 
                                " DepartmentID, " + 
                                " TotalLeaveAllotted, " + 
                                " TotalLeaveAvailed, " + 
                                " TotalLeaveBalance, " + 
                                " 'Highest Balance' AS BalanceCategory " + 
                            " FROM " +
                                " qryEmpLeaveBalanceHighest " +
                            " UNION ALL " +
                            " SELECT " + 
                                " EmpID, " + 
                                " EmpName, " + 
                                " DepartmentID, " + 
                                " TotalLeaveAllotted, " + 
                                " TotalLeaveAvailed, " + 
                                " TotalLeaveBalance, " + 
                                " 'Lowest Balance' AS BalanceCategory " + 
                            " FROM " + 
                                " qryEmpLeaveBalanceLowest " + 
                            " UNION ALL " + 
                            " SELECT " + 
                                " EmpID, " + 
                                " EmpName, " + 
                                " DepartmentID, " + 
                                " TotalLeaveAllotted, " + 
                                " TotalLeaveAvailed, " + 
                                " TotalLeaveBalance, " + 
                                " 'Zero Balance' AS BalanceCategory " + 
                            " FROM " + 
                                " qryEmpLeaveBalanceZero;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objLeaveInfoEmpWiseChartData = JsonConvert.DeserializeObject<List<LeaveInfoEmpWiseChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objLeaveInfoEmpWiseChartData;
        }

        public List<AttendanceCalendarChartData01> displayAttendanceCalendarChartData(int txtClientID, DateTime dtFromDate, DateTime dtToDate)
        {
            List<AttendanceCalendarChartData01> objAttendanceCalendarChartDataList = new List<AttendanceCalendarChartData01>();

            DataTable dt = new DataTable();

            OleDbConnection conn = null;

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " DateValue (A.AttDate) AS AttendanceDate, " +
                                        " Sum(IIf(A.AttStatus = \"Present\", 1, 0)) AS PresentCount, " +
                                        " Sum(IIf(A.AttStatus = \"Leave : Full Day\", 1, 0)) AS LeaveCount, " +
                                        " Sum(IIf(InStr (1, A.AttStatus, \"Cancelled\", 1) > 0, 1, 0) ) AS CancelledCount, " +
                                        " Sum(IIf(InStr (1, A.AttStatus, \"Rejected\", 1) > 0, 1, 0)) AS RejectedCount " +
                                    " FROM " +
                                        " (" +
                                            " ClientMas AS C INNER JOIN EmpMas AS E ON C.ClientID = E.ClientID " +
                                        " ) " +
                                        " INNER JOIN EmpDailyAttendanceInfo AS A ON E.EmpID = A.EmpID " +
                                    " WHERE " +
                                        " E.ClientID = " + txtClientID + 
                                        " AND E.IsActive = True " +
                                        " AND E.IsDeleted = False " +
                                        " AND A.AttDate >= #" + dtFromDate.ToString("yyyy-MM-dd") + "# " +
                                        " AND A.AttDate<  #" + dtToDate.ToString("yyyy-MM-dd") + "# " +
                                        " AND A.AttID = (" +
                                            " SELECT " +
                                                " Max(A2.AttID) " +
                                            " FROM " +
                                                " EmpDailyAttendanceInfo AS A2 " +
                                            " WHERE " +
                                                " A2.EmpID = A.EmpID " +
                                                " AND A2.AttDate = A.AttDate " +
                                        " ) " +
                                    " GROUP BY " +
                                        " DateValue (A.AttDate) " +
                                    " ORDER BY " +
                                        " DateValue (A.AttDate);";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAttendanceCalendarChartDataList = JsonConvert.DeserializeObject<List<AttendanceCalendarChartData01>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objAttendanceCalendarChartDataList;
        }

        public List<EmployeeAttendanceSummaryChartData> displayAttendanceSummaryChartData(int clientID, DateTime fromDate, DateTime toDate)
        {
            List<EmployeeAttendanceSummaryChartData> objEmployeeAttendanceSummaryChartDataList = new List<EmployeeAttendanceSummaryChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"
                                        SELECT
                                            DepMas.DepartmentTitle,
                                            A.AttDate AS AttendanceDate,

                                            Sum(
                                                IIf(
                                                    A.AttStatus = ""Present"",
                                                    1,
                                                    0
                                                )
                                            ) AS PresentCount,

                                            Sum(
                                                IIf(
                                                    Left(
                                                        IIf(
                                                            IsNull(A.AttStatus),
                                                            """",
                                                            A.AttStatus
                                                        ),
                                                        5
                                                    ) = ""Leave"",
                                                    1,
                                                    0
                                                )
                                            ) AS LeaveCount,

                                            Sum(
                                                IIf(
                                                    A.AttStatus = ""Cancelled"",
                                                    1,
                                                    0
                                                )
                                            ) AS CancelledCount,

                                            Sum(
                                                IIf(
                                                    A.AttStatus = ""Rejected"",
                                                    1,
                                                    0
                                                )
                                            ) AS RejectedCount

                                        FROM
                                            (
                                                DepMas
                                                INNER JOIN EmpMas AS E
                                                    ON DepMas.DepartmentID = E.DepartmentID
                                            )
                                            INNER JOIN EmpDailyAttendanceInfo AS A
                                                ON E.EmpID = A.EmpID

                                        WHERE
                                            E.ClientID = " + clientID + @" 
                                            AND E.IsActive = True
                                            AND E.IsDeleted = False

                                            AND A.AttID =
                                            (
                                                SELECT
                                                    Max(A2.AttID)
                                                FROM
                                                    EmpDailyAttendanceInfo AS A2
                                                WHERE
                                                    A2.EmpID = A.EmpID
                                                    AND A2.AttDate = A.AttDate
                                            )

                                            AND A.AttDate >= #" + fromDate.ToString("yyyy-MM-dd") + "# " + @" 
                                            AND A.AttDate < #" + toDate.ToString("yyyy-MM-dd") + "# " + @" 

                                        GROUP BY
                                            DepMas.DepartmentTitle,
                                            A.AttDate

                                        ORDER BY
                                            DepMas.DepartmentTitle,
                                            A.AttDate";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAttendanceSummaryChartDataList = JsonConvert.DeserializeObject<List<EmployeeAttendanceSummaryChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objEmployeeAttendanceSummaryChartDataList;
        }


        public List<UpcomingPlannedLeaveChartData> displayUpcomingPlannedLeavesChartData(int clientID, DateTime fromDate, DateTime toDate)
        {
            List<UpcomingPlannedLeaveChartData> objUpcomingPlannedLeaveChartDataList = new List<UpcomingPlannedLeaveChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        E.EmpID AS EmpID,E.EmpCode AS EmpCode,
                                        E.EmpName AS EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        L.ActualLeaveDateFrom AS LeaveDate,
                                        LT.LeaveTypeTitle AS LeaveType,
                                        DateDiff(""d"", Date(), L.ActualLeaveDateFrom) AS DaysToGo
                                    FROM
                                        DesigMas
                                        INNER JOIN (
                                            (
                                                LeaveTypeMas AS LT
                                                INNER JOIN (
                                                    EmpMas AS E
                                                    INNER JOIN EmpLeaveTransMas AS L ON E.EmpID = L.EmpID
                                                ) ON LT.LeaveTypeID = L.LeaveTypeID
                                            )
                                            INNER JOIN DepMas ON E.DepartmentID = DepMas.DepartmentID
                                        ) ON DesigMas.DesignationID = E.EmpDesignationID
                                    WHERE
                                            ((E.EmpID) > 1)
                                            AND ((DateDiff(""d"", Date(), L.ActualLeaveDateFrom)) > 0)                                            
                                            AND ((L.ActualLeaveDateFrom) >= DateSerial(" + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Year + ", " + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Month + ", " + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Day + @") 
                                            AND ((E.ClientID) = " + clientID + ") " + @"
                                            AND ((E.IsActive) = True)
                                            AND ((E.IsDeleted) = False)
                                            AND ((Left(IIf(IsNull([L].[LeaveApprovalComments]),"""", [L].[LeaveApprovalComments]), 10)) = ""Approved :""))
                                    ORDER BY
                                        E.EmpID,
                                        L.ActualLeaveDateFrom,
                                        E.EmpName, E.EmpCode Asc;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objUpcomingPlannedLeaveChartDataList = JsonConvert.DeserializeObject<List<UpcomingPlannedLeaveChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objUpcomingPlannedLeaveChartDataList;
        }

        public List<ApprovalPendindingLeavesChartData> displayPendingApprovalLeaveChartData(int clientID, DateTime fromDate, DateTime toDate)
        {
            List<ApprovalPendindingLeavesChartData> objApprovalPendindingLeavesChartDataList = new List<ApprovalPendindingLeavesChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        E.EmpID AS EmpID, E.EmpCode AS EmpCode,
                                        E.EmpName AS EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        L.ActualLeaveDateFrom AS LeaveDate,
                                        LT.LeaveTypeTitle AS LeaveType,
                                        ABS(DateDiff(""d"", Date(), L.ActualLeaveDateFrom)) AS DaysToGo
                                    FROM
                                        LeaveTypeMas AS LT
                                        INNER JOIN (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN EmpMas AS E ON DepMas.DepartmentID = E.DepartmentID
                                                ) ON DesigMas.DesignationID = E.EmpDesignationID
                                            )
                                            INNER JOIN EmpLeaveTransMas AS L ON E.EmpID = L.EmpID
                                        ) ON LT.LeaveTypeID = L.LeaveTypeID
                                    WHERE
                                        (
                                            ((E.EmpID) > 1)
                                            AND (
                                                (L.ActualLeaveDateFrom) >= #" + fromDate.ToString("dd-MMM-yyyy") + @"#
                                                AND (L.ActualLeaveDateFrom) <= #" + toDate.ToString("dd-MMM-yyyy") + @"#
                                            )
                                            AND (
                                                (DateDiff(""d"", Date(), [L].[ActualLeaveDateFrom])) < 0
                                            )
                                            AND ((E.ClientID) = " + clientID + @")
                                            AND ((E.IsActive) = True)
                                            AND ((E.IsDeleted) = False)
                                            AND ((L.Canceled) = False)
                                            AND ((L.LeaveApprovalComments) = ""Not yet Approved"")
                                            AND ((L.LeaveRejectionComments) = ""Not yet Rejected"")
                                        )
                                    ORDER BY
                                        E.EmpID,
                                        L.ActualLeaveDateFrom,
                                        E.EmpName, E.EmpCode Asc;";

                strQuery = @"SELECT TOP 5 
                                    E.EmpID AS EmpID,
                                    E.EmpCode AS EmpCode,
                                    E.EmpName AS EmpName,
                                    DesigMas.DesignationTitle,
                                    DepMas.DepartmentTitle,
                                    L.ActualLeaveDateFrom AS LeaveDate,
                                    LT.LeaveTypeTitle AS LeaveType,
                                    DateDiff(""d"", Date(), L.ActualLeaveDateFrom) AS DaysToGo

                                FROM
                                    LeaveTypeMas AS LT
                                    INNER JOIN
                                    (
                                        (
                                            DesigMas
                                            INNER JOIN
                                            (
                                                DepMas
                                                INNER JOIN EmpMas AS E
                                                    ON DepMas.DepartmentID = E.DepartmentID
                                            )
                                            ON DesigMas.DesignationID = E.EmpDesignationID
                                        )
                                        INNER JOIN EmpLeaveTransMas AS L
                                            ON E.EmpID = L.EmpID
                                    )
                                    ON LT.LeaveTypeID = L.LeaveTypeID

                                WHERE
                                    E.EmpID > 1
                                    AND L.ActualLeaveDateFrom >= DateSerial(" + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Year + ", " + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Month + ", " + Convert.ToDateTime(fromDate.ToString("dd-MMM-yyyy")).Day + @") 
                                    AND L.ActualLeaveDateFrom < DateSerial(" + (Convert.ToDateTime(toDate.ToString("dd-MMM-yyyy")).Year + 1) + ", " + Convert.ToDateTime(toDate.ToString("dd-MMM-yyyy")).Month + ", " + Convert.ToDateTime(toDate.ToString("dd-MMM-yyyy")).Day + @") 
                                    AND E.ClientID = " + clientID + @"
                                    AND E.IsActive = True
                                    AND E.IsDeleted = False
                                    AND L.Canceled = False

                                    AND L.LeaveApprovalComments = ""Not yet Approved""
                                    AND L.LeaveRejectionComments = ""Not yet Rejected""

                                ORDER BY
                                    E.EmpID,
                                    L.ActualLeaveDateFrom,
                                    E.EmpName, E.EmpCode Asc;";
                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objApprovalPendindingLeavesChartDataList = JsonConvert.DeserializeObject<List<ApprovalPendindingLeavesChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objApprovalPendindingLeavesChartDataList;
        }

        public List<EmployeeBirthdayChartData> displayBirthdayEmployeesChartData(int clientID, DateTime dtBirthdayDate)
        {
            List<EmployeeBirthdayChartData> objEmployeeBirthdayChartDataList  = new List<EmployeeBirthdayChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        PersonalInfoMas.DOB,
                                        Photos.PhotoID,
                                        Photos.EmpPhoto,
                                        EmpMas.IsActive,
                                        EmpMas.IsDeleted,
                                        ClientMas.ClientID
                                    FROM
                                        (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN (
                                                        ClientMas
                                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                    ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                            )
                                            INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                        )
                                        LEFT JOIN Photos ON EmpMas.EmpID = Photos.EmpID
                                    WHERE
                                        (
                                            ((EmpMas.EmpID) > 1)
                                            AND ((Month([PersonalInfoMas].[DOB])) = Month(Date()))
                                            AND ((Day([PersonalInfoMas].[DOB])) = Day(Date()))
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND ((EmpMas.ResignedStatus) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                            AND ((ClientMas.ClientID) = " + clientID + @")
                                        )
                                    ORDER BY
                                        EmpMas.EmpID,
                                        EmpMas.EmpName;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeBirthdayChartDataList = JsonConvert.DeserializeObject<List<EmployeeBirthdayChartData>>(DataTableToJSon);
                //foreach (EmployeeBirthdayChartData indEmployeeBirthdayChartData in objEmployeeBirthdayChartDataList)
                //{
                //    indEmployeeBirthdayChartData.EmpPhotoBase64 = indEmployeeBirthdayChartData.EmpPhoto;

                //}
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objEmployeeBirthdayChartDataList;
        }

        public List<EmployeeDateOfJoiningChartData> displayDateOfJoiningEmployeesChartData(int clientID, DateTime dtDateOfJoining)
        {
            List<EmployeeDateOfJoiningChartData> objEmployeeDateOfJoiningChartData = new List<EmployeeDateOfJoiningChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        PersonalInfoMas.DOJ,
                                        Photos.PhotoID,
                                        Photos.EmpPhoto,
                                        EmpMas.IsActive,
                                        EmpMas.IsDeleted,
                                        EmpMas.ResignedStatus,
                                        PersonalInfoMas.GoldProfile,
                                        ClientMas.ClientID
                                    FROM
                                        (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN (
                                                        ClientMas
                                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                    ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                            )
                                            INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                        )
                                        LEFT JOIN Photos ON EmpMas.EmpID = Photos.EmpID
                                    WHERE
                                        (
                                            ((EmpMas.EmpID) > 1)
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND ((EmpMas.ResignedStatus) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                            AND ((ClientMas.ClientID) = " + clientID + @")
                                            AND ((Month([PersonalInfoMas].[DOJ])) = Month(Date()))
                                            AND ((Day([PersonalInfoMas].[DOJ])) = Day(Date()))
                                        )
                                    ORDER BY
                                        EmpMas.EmpID,
                                        EmpMas.EmpName;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeDateOfJoiningChartData = JsonConvert.DeserializeObject<List<EmployeeDateOfJoiningChartData>>(DataTableToJSon);
                //foreach (EmployeeBirthdayChartData indEmployeeBirthdayChartData in objEmployeeBirthdayChartDataList)
                //{
                //    indEmployeeBirthdayChartData.EmpPhotoBase64 = indEmployeeBirthdayChartData.EmpPhoto;

                //}
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objEmployeeDateOfJoiningChartData;
        }


        public List<EmployeeConfirmationDayChartData> displayEmployeesConfirmationChartData(int clientID, DateTime dtConfirmationDate)
        {
            List<EmployeeConfirmationDayChartData> objEmployeesConfirmationChartDataList = new List<EmployeeConfirmationDayChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        PersonalInfoMas.DateOfConfirmation,
                                        Photos.PhotoID,
                                        Photos.EmpPhoto,
                                        EmpMas.IsActive,
                                        EmpMas.IsDeleted,
                                        ClientMas.ClientID
                                    FROM
                                        (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN (
                                                        ClientMas
                                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                    ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                            )
                                            INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                        )
                                        LEFT JOIN Photos ON EmpMas.EmpID = Photos.EmpID
                                    WHERE
                                        (
                                            ((EmpMas.EmpID) > 1)
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND ((EmpMas.ResignedStatus) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                            AND ((ClientMas.ClientID) = " + clientID + @")
                                            AND (
                                                (Month([PersonalInfoMas].[DateOfConfirmation])) = Month(Date())
                                            )
                                            AND (
                                                (Day([PersonalInfoMas].[DateOfConfirmation])) = Day(Date())
                                            )
                                        )
                                    ORDER BY
                                        EmpMas.EmpID,
                                        EmpMas.EmpName;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeesConfirmationChartDataList = JsonConvert.DeserializeObject<List<EmployeeConfirmationDayChartData>>(DataTableToJSon);
                //foreach (EmployeeBirthdayChartData indEmployeeBirthdayChartData in objEmployeeBirthdayChartDataList)
                //{
                //    indEmployeeBirthdayChartData.EmpPhotoBase64 = indEmployeeBirthdayChartData.EmpPhoto;

                //}
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objEmployeesConfirmationChartDataList;
        }

        //public async Task<List<MonthlyAttendanceRegisterRow>> displayMonthlyAttendanceRegisterData(int clientId, int year) //, CancellationToken cancellationToken = default)
        //{
        //    return await Task.Run(() =>
        //    {
        //        List<MonthlyAttendanceRegisterRow> objMonthlyAttendanceRegisterRowList = new List<MonthlyAttendanceRegisterRow>();

        //        try
        //        {
        //            conn = dbStaffSync.openDBConnection();

        //            string strQuery = @"SELECT
        //                        ""MONTH"" AS RecordType,
        //                        Month(Q.AttendanceDate) AS MonthNo,
        //                        Format(Q.AttendanceDate, ""mmm"") AS MonthName,
        //                        Null AS EmpID,
        //                        Null AS EmpCode,
        //                        Null AS EmployeeName,
        //                        Null AS AttendanceDate,
        //                        Null AS AttendanceStatus,
        //                        Sum(IIf(Q.AttStatus = ""Present"", 1, 0)) AS PresentCount,
        //                        Sum(IIf(Q.AttStatus = ""Leave : Full Day"", 1, 0)) AS LeaveCount,
        //                        Sum(IIf(InStr(1, Q.AttStatus, ""Cancelled"", 1) > 0, 1, 0)) AS CancelledCount,
        //                        Sum(IIf(InStr(1, Q.AttStatus, ""Rejected"", 1) > 0, 1, 0)) AS RejectedCount
        //                    FROM
        //                        (
        //                            SELECT
        //                                E.EmpID,
        //                                E.EmpCode AS EmpCode,
        //                                E.EmpName AS EmployeeName,
        //                                DateValue(A.AttDate) AS AttendanceDate,
        //                                A.AttStatus
        //                            FROM
        //                                (ClientMas AS C
        //                                INNER JOIN EmpMas AS E
        //                                    ON C.ClientID = E.ClientID)
        //                                INNER JOIN EmpDailyAttendanceInfo AS A
        //                                    ON E.EmpID = A.EmpID
        //                            WHERE
        //                                E.ClientID = " + clientId + @"
        //                                AND E.IsActive = True
        //                                AND E.IsDeleted = False
        //                                AND A.AttDate >= DateSerial(" + year + @", 1, 1)
        //                                AND A.AttDate < DateSerial(" + (year + 1) + @", 1, 1)
        //                                AND A.AttID =
        //                                    (
        //                                        SELECT Max(A2.AttID)
        //                                        FROM EmpDailyAttendanceInfo AS A2
        //                                        WHERE
        //                                            A2.EmpID = A.EmpID
        //                                            AND DateValue(A2.AttDate) =
        //                                                DateValue(A.AttDate)
        //                                    )
        //                        ) AS Q
        //                    GROUP BY
        //                        Month(Q.AttendanceDate),
        //                        Format(Q.AttendanceDate, ""mmm"")

        //                    UNION ALL

        //                    SELECT
        //                        ""DETAIL"" AS RecordType,
        //                        Month(DateValue(A.AttDate)) AS MonthNo,
        //                        Format(DateValue(A.AttDate), ""mmm"") AS MonthName,
        //                        E.EmpID,
        //                        E.EmpCode AS EmpCode,
        //                        E.EmpName AS EmployeeName,
        //                        DateValue(A.AttDate) AS AttendanceDate,
        //                        A.AttStatus AS AttendanceStatus,
        //                        Null AS PresentCount,
        //                        Null AS LeaveCount,
        //                        Null AS CancelledCount,
        //                        Null AS RejectedCount
        //                    FROM
        //                        (ClientMas AS C
        //                        INNER JOIN EmpMas AS E
        //                            ON C.ClientID = E.ClientID)
        //                        INNER JOIN EmpDailyAttendanceInfo AS A
        //                            ON E.EmpID = A.EmpID
        //                    WHERE
        //                        E.ClientID = " + clientId + @"
        //                        AND E.IsActive = True
        //                        AND E.IsDeleted = False
        //                        AND A.AttDate >= DateSerial(" + year + @", 1, 1)
        //                        AND A.AttDate < DateSerial(" + (year + 1) + @", 1, 1)
        //                        AND A.AttID =
        //                            (
        //                                SELECT Max(A2.AttID)
        //                                FROM EmpDailyAttendanceInfo AS A2
        //                                WHERE
        //                                    A2.EmpID = A.EmpID
        //                                    AND DateValue(A2.AttDate) =
        //                                        DateValue(A.AttDate)
        //                            )

        //                    ORDER BY
        //                        RecordType,
        //                        MonthNo,
        //                        EmpCode,
        //                        EmployeeName,
        //                        AttendanceDate;";

        //            //DataTable dt = new DataTable();

        //            //OleDbCommand cmd = conn.CreateCommand();
        //            //cmd.CommandType = CommandType.Text;
        //            //cmd.CommandText = strQuery;
        //            //cmd.ExecuteNonQueryAsync();

        //            //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        //            //da.Fill(dt);

        //            //string DataTableToJSon = JsonConvert.SerializeObject(dt);
        //            //objMonthlyAttendanceRegisterRowList = JsonConvert.DeserializeObject<List<MonthlyAttendanceRegisterRow>>(DataTableToJSon);

        //            DataTable dt = new DataTable();

        //            OleDbCommand cmd = conn.CreateCommand();
        //            cmd.CommandType = CommandType.Text;
        //            cmd.CommandText = strQuery;

        //            // IMPORTANT:
        //            // Do NOT call ExecuteNonQuery() for this SELECT.

        //            OleDbDataAdapter da = new OleDbDataAdapter(cmd);

        //            da.Fill(dt);

        //            string DataTableToJson = JsonConvert.SerializeObject(dt);

        //            objMonthlyAttendanceRegisterRowList = JsonConvert.DeserializeObject<List<MonthlyAttendanceRegisterRow>>(DataTableToJson);

        //            return objMonthlyAttendanceRegisterRowList;

        //        }
        //        catch (Exception)
        //        {
        //            // Log if required
        //        }
        //        finally
        //        {
        //            if (conn != null)
        //            {
        //                dbStaffSync.closeDBConnection();
        //            }
        //        }

        //        return objMonthlyAttendanceRegisterRowList;
        //    });
        //}

        public async Task<List<MonthlyAttendanceRegisterRow>>
            displayMonthlyAttendanceRegisterData(int clientId, int year)
        {
            return await Task.Run(() =>
            {
                List<MonthlyAttendanceRegisterRow> objMonthlyAttendanceRegisterRowList =
                    new List<MonthlyAttendanceRegisterRow>();

                try
                {
                    // Create an independent connection for this operation.
                    using (OleDbConnection localConn =
                           dbStaffSync.CreateDBConnection())
                    {
                        string strQuery = @"SELECT
                            ""MONTH"" AS RecordType,
                            Month(Q.AttendanceDate) AS MonthNo,
                            Format(Q.AttendanceDate, ""mmm"") AS MonthName,
                            Null AS EmpID,
                            Null AS EmpCode,
                            Null AS EmployeeName,
                            Null AS AttendanceDate,
                            Null AS AttendanceStatus,
                            Sum(IIf(Q.AttStatus = ""Present"", 1, 0)) AS PresentCount,
                            Sum(IIf(Q.AttStatus = ""Leave : Full Day"", 1, 0)) AS LeaveCount,
                            Sum(IIf(InStr(1, Q.AttStatus, ""Cancelled"", 1) > 0, 1, 0)) AS CancelledCount,
                            Sum(IIf(InStr(1, Q.AttStatus, ""Rejected"", 1) > 0, 1, 0)) AS RejectedCount
                        FROM
                            (
                                SELECT
                                    E.EmpID,
                                    E.EmpCode AS EmpCode,
                                    E.EmpName AS EmployeeName,
                                    DateValue(A.AttDate) AS AttendanceDate,
                                    A.AttStatus
                                FROM
                                    (ClientMas AS C
                                    INNER JOIN EmpMas AS E
                                        ON C.ClientID = E.ClientID)
                                    INNER JOIN EmpDailyAttendanceInfo AS A
                                        ON E.EmpID = A.EmpID
                                WHERE
                                    E.ClientID = " + clientId + @"
                                    AND E.IsActive = True
                                    AND E.IsDeleted = False
                                    AND A.AttDate >= DateSerial(" + year + @", 1, 1)
                                    AND A.AttDate < DateSerial(" + (year + 1) + @", 1, 1)
                                    AND A.AttID =
                                        (
                                            SELECT Max(A2.AttID)
                                            FROM EmpDailyAttendanceInfo AS A2
                                            WHERE
                                                A2.EmpID = A.EmpID
                                                AND DateValue(A2.AttDate) =
                                                    DateValue(A.AttDate)
                                        )
                            ) AS Q
                        GROUP BY
                            Month(Q.AttendanceDate),
                            Format(Q.AttendanceDate, ""mmm"")

                        UNION ALL

                        SELECT
                            ""DETAIL"" AS RecordType,
                            Month(DateValue(A.AttDate)) AS MonthNo,
                            Format(DateValue(A.AttDate), ""mmm"") AS MonthName,
                            E.EmpID,
                            E.EmpCode AS EmpCode,
                            E.EmpName AS EmployeeName,
                            DateValue(A.AttDate) AS AttendanceDate,
                            A.AttStatus AS AttendanceStatus,
                            Null AS PresentCount,
                            Null AS LeaveCount,
                            Null AS CancelledCount,
                            Null AS RejectedCount
                        FROM
                            (ClientMas AS C
                            INNER JOIN EmpMas AS E
                                ON C.ClientID = E.ClientID)
                            INNER JOIN EmpDailyAttendanceInfo AS A
                                ON E.EmpID = A.EmpID
                        WHERE
                            E.ClientID = " + clientId + @"
                            AND E.IsActive = True
                            AND E.IsDeleted = False
                            AND A.AttDate >= DateSerial(" + year + @", 1, 1)
                            AND A.AttDate < DateSerial(" + (year + 1) + @", 1, 1)
                            AND A.AttID =
                                (
                                    SELECT Max(A2.AttID)
                                    FROM EmpDailyAttendanceInfo AS A2
                                    WHERE
                                        A2.EmpID = A.EmpID
                                        AND DateValue(A2.AttDate) =
                                            DateValue(A.AttDate)
                                )

                        ORDER BY
                            RecordType,
                            MonthNo,
                            EmpCode,
                            EmployeeName,
                            AttendanceDate;";

                        using (OleDbCommand cmd = localConn.CreateCommand())
                        {
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = strQuery;

                            using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                            {
                                DataTable dt = new DataTable();

                                da.Fill(dt);

                                string DataTableToJson =
                                    JsonConvert.SerializeObject(dt);

                                objMonthlyAttendanceRegisterRowList =
                                    JsonConvert.DeserializeObject<
                                        List<MonthlyAttendanceRegisterRow>
                                    >(DataTableToJson)
                                    ?? new List<MonthlyAttendanceRegisterRow>();
                            }
                        }
                    }

                    return objMonthlyAttendanceRegisterRowList;
                }
                catch (Exception ex)
                {
                    // Keep the actual exception visible during debugging.
                    System.Diagnostics.Debug.WriteLine(
                        "Monthly Attendance Register Error: " + ex);

                    throw;
                }
            });
        }

        public List<MonthlyAttendanceRegisterRow> GetMonthlyAttendanceRegisterDataByEmpID(int EmpID) //, CancellationToken cancellationToken = default)
        {            
            List<MonthlyAttendanceRegisterRow> objMonthlyAttendanceRegisterRowList = new List<MonthlyAttendanceRegisterRow>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        ""MONTH"" AS RecordType,
                                        Q.EmpID AS EmpID,
                                        Format(Q.AttendanceDate, ""mmm"") AS MonthName,
                                        Month(Q.AttendanceDate) AS MonthNo,
                                        Year(Q.AttendanceDate) AS YearNo,
                                        Format(Q.AttendanceDate, ""mmm"") & "" - "" & Year(Q.AttendanceDate) AS MonthYear,
                                        Day(DateSerial(Year(Q.AttendanceDate), Month(Q.AttendanceDate) + 1, 0)) AS TotalDays,
                                        Sum(IIf(Q.AttStatus = ""Present"", 1, 0)) AS PresentCount,
                                        Sum(IIf(Q.AttStatus = ""Leave : Full Day"", 1, 0)) AS LeaveCount,
                                        Sum(
                                            IIf(InStr (1, Q.AttStatus, ""Cancelled"", 1) > 0, 1, 0)
                                        ) AS CancelledCount,
                                        Sum(
                                            IIf(InStr (1, Q.AttStatus, ""Rejected"", 1) > 0, 1, 0)
                                        ) AS RejectedCount,
                                        Sum(
                                            IIf(Q.AttStatus = ""Present"", 1, 0) + IIf(Q.AttStatus = ""Leave : Full Day"", 1, 0)
                                        ) AS PayableDays
                                    FROM
                                        (
                                            SELECT
                                                E.EmpID,
                                                DateValue (A.AttDate) AS AttendanceDate,
                                                A.AttStatus
                                            FROM
                                                (
                                                    ClientMas AS C
                                                    INNER JOIN EmpMas AS E ON C.ClientID = E.ClientID
                                                )
                                                INNER JOIN EmpDailyAttendanceInfo AS A ON E.EmpID = A.EmpID
                                            WHERE
                                                E.EmpID = " + EmpID + @"
                                                AND E.IsActive = True
                                                AND E.IsDeleted = False
                                                AND A.AttID = (
                                                    SELECT
                                                        Max(A2.AttID)
                                                    FROM
                                                        EmpDailyAttendanceInfo AS A2
                                                    WHERE
                                                        A2.EmpID = A.EmpID
                                                        AND DateValue (A2.AttDate) = DateValue (A.AttDate)
                                                )
                                        ) AS Q
                                    GROUP BY
                                        Q.EmpID,
                                        Format(Q.AttendanceDate, ""mmm""),
                                        Year(Q.AttendanceDate),
                                        Day(
                                            DateSerial (
                                                Year(Q.AttendanceDate),
                                                Month(Q.AttendanceDate) + 1,
                                                0
                                            )
                                        ),
                                        Month(Q.AttendanceDate)
                                    HAVING
                                        (((Q.EmpID) = " + EmpID + @"))
                                    ORDER BY
                                        Year(Q.AttendanceDate),
                                        Month(Q.AttendanceDate);";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;

                // IMPORTANT:
                // Do NOT call ExecuteNonQuery() for this SELECT.

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                da.Fill(dt);

                string DataTableToJson = JsonConvert.SerializeObject(dt);

                objMonthlyAttendanceRegisterRowList = JsonConvert.DeserializeObject<List<MonthlyAttendanceRegisterRow>>(DataTableToJson);

                return objMonthlyAttendanceRegisterRowList;

            }
            catch (Exception)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objMonthlyAttendanceRegisterRowList;
        }

        public List<EmployeeAdvanceInformationChartData> displayEmployeeAdvanceInformationChartData(int clientId, DateTime dtFrom, DateTime dtTo) //, CancellationToken cancellationToken = default)
        {
            List<EmployeeAdvanceInformationChartData> objEmployeeAdvanceInformationRowList = new List<EmployeeAdvanceInformationChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        PersonalInfoMas.DOB,
                                        PersonalInfoMas.DOJ,
                                        AdvanceTypeMas.AdvanceTypeID,
                                        AdvanceTypeMas.AdvanceTypeTitle,
                                        EmpAdvanceRequestMas.EmpAdvanceRequestID,
                                        EmpAdvanceRequestMas.EmpAdvReqCode,
                                        EmpAdvanceRequestMas.RequestMovedToComments,
                                        EmpAdvanceRequestMas.AdvanceAmount,
                                        EmpAdvanceRequestMas.AdvanceTenure,
                                        EmpAdvanceRequestMas.AdvanceInstallment,
                                        EmpAdvanceRequestMas.AdvanceStartDate,
                                        EmpAdvanceRequestMas.AdvanceEndDate,
                                        EmpAdvanceDetails.EmpAdvanceRecoveryID,
                                        EmpAdvanceDetails.AdvanceDate,
                                        Year(EmpAdvanceDetails.AdvanceDate) AS AdvanceYear,
                                        Month(EmpAdvanceDetails.AdvanceDate) AS AdvanceMonth,
                                        Format(EmpAdvanceDetails.AdvanceDate, ""mmm-yyyy"") AS AdvanceMonthName,
                                        Day(EmpAdvanceDetails.AdvanceDate) AS AdvanceDay,
                                        EmpAdvanceDetails.OBalance,
                                        EmpAdvanceDetails.CrBalance,
                                        EmpAdvanceDetails.DrBalance,
                                        EmpAdvanceDetails.CBalance,
                                        EmpAdvanceDetails.TRType,
                                        EmpAdvanceDetails.Comments,
                                        IIf(
                                            EmpAdvanceRequestMas.RequestMovedToComments = ""Pending""
                                            OR EmpAdvanceRequestMas.RequestMovedToComments = ""Approved"",
                                            EmpAdvanceRequestMas.AdvanceAmount,
                                            0
                                        ) AS RequestAmount,
                                        IIf(
                                            EmpAdvanceRequestMas.RequestMovedToComments = ""Approved"",
                                            EmpAdvanceRequestMas.AdvanceAmount,
                                            0
                                        ) AS IssuedAmount,
                                        IIf(
                                            EmpAdvanceDetails.CBalance > 0,
                                            EmpAdvanceDetails.CBalance,
                                            0
                                        ) AS OutstandingAmount,
                                        (
                                            IIf(
                                                EmpAdvanceRequestMas.RequestMovedToComments = ""Pending""
                                                OR EmpAdvanceRequestMas.RequestMovedToComments = ""Approved"",
                                                EmpAdvanceRequestMas.AdvanceAmount,
                                                0
                                            ) - IIf(
                                                EmpAdvanceDetails.CBalance > 0,
                                                EmpAdvanceDetails.CBalance,
                                                0
                                            )
                                        ) AS RecoveredAmount,
                                        ClientMas.ClientID
                                    FROM
                                        (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN (
                                                        ClientMas
                                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                    ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                            )
                                            INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                        )
                                        INNER JOIN (
                                            (
                                                AdvanceTypeMas
                                                INNER JOIN EmpAdvanceRequestMas ON AdvanceTypeMas.AdvanceTypeID = EmpAdvanceRequestMas.AdvanceTypeID
                                            )
                                            INNER JOIN EmpAdvanceDetails ON EmpAdvanceRequestMas.EmpAdvanceRequestID = EmpAdvanceDetails.EmpAdvanceRequestID
                                        ) ON PersonalInfoMas.PersonalInfoID = EmpAdvanceRequestMas.PersonalInfoID
                                    WHERE
                                        (
                                            EmpMas.EmpID > 0
                                            AND EmpAdvanceDetails.EmpAdvanceRecoveryID = (
                                                SELECT
                                                    Max(D2.EmpAdvanceRecoveryID)
                                                FROM
                                                    EmpAdvanceDetails AS D2
                                                WHERE
                                                    D2.EmpAdvanceRequestID = EmpAdvanceDetails.EmpAdvanceRequestID
                                            )
                                            AND EmpAdvanceDetails.AdvanceDate >= #" + dtFrom.ToString("dd-MMM-yyyy") + @"#
                                            AND EmpAdvanceDetails.AdvanceDate < #" + dtTo.ToString("dd-MMM-yyyy") + @"#
                                            AND ClientMas.ClientID = " + clientId + @"
                                        )
                                    ORDER BY
                                        AdvanceTypeMas.AdvanceTypeTitle,
                                        EmpAdvanceDetails.AdvanceDate,
                                        EmpMas.EmpName,
                                        EmpAdvanceRequestMas.EmpAdvanceRequestID;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAdvanceInformationRowList = JsonConvert.DeserializeObject<List<EmployeeAdvanceInformationChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objEmployeeAdvanceInformationRowList;
        }

        public List<AssetRegisterChartData> displayAssetRegisterChartData(int clientId) //, CancellationToken cancellationToken = default)
        {
            List<AssetRegisterChartData> objAssetRegisterChartDataList = new List<AssetRegisterChartData>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = @"SELECT
                                        AssetCategoryMas.AssetCatMasID,
                                        AssetCategoryMas.AssetCode AS AssetCatCode,
                                        AssetCategoryMas.AssetName AS AssetCatName,
                                        AssetCategoryMas.AssetDescription AS AssetCatDesc,
                                        AssetMas.AssetID,
                                        AssetMas.AssetCode,
                                        AssetMas.AssetName,
                                        CurrentAssetStatus.CurrentAssetStatusName,
                                        AssetMasMoreDetails.SerialNumber,
                                        AssetMasMoreDetails.ModelNumber,
                                        AssetMasMoreDetails.ManufacturerInfo,
                                        AssetMasMoreDetails.AssetTag,
                                        AssetMasMoreDetails.PurchaseDate,
                                        AssetMasMoreDetails.PurchaseValue,
                                        AssetMasMoreDetails.VendorName,
                                        AssetMasMoreDetails.InvoiceNumber,
                                        AssetMasMoreDetails.WarrantyStartDate,
                                        AssetMasMoreDetails.WarrantyEndDate,
                                        AssetMasMoreDetails.HasWarranty,
                                        AssetMasMoreDetails.NextServiceDate,
                                        AssetMasMoreDetails.Location,
                                        AssetMas.TotalQuantity,
                                        AssetMas.OutstandingQuantity,
                                        EmpMas.EmpID,
                                        EmpMas.EmpCode,
                                        EmpMas.EmpName,
                                        DesigMas.DesignationTitle,
                                        DepMas.DepartmentTitle,
                                        ClientMas.ClientID
                                    FROM
                                        (
                                            DesigMas
                                            INNER JOIN (
                                                DepMas
                                                INNER JOIN EmpMas ON DepMas.DepartmentID = EmpMas.DepartmentID
                                            ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                        )
                                        INNER JOIN (
                                            CurrentAssetStatus
                                            INNER JOIN (
                                                ClientMas
                                                INNER JOIN (
                                                    (
                                                        (
                                                            AssetCategoryMas
                                                            INNER JOIN AssetMas ON AssetCategoryMas.AssetCatMasID = AssetMas.AssetCatMasID
                                                        )
                                                        INNER JOIN AssetMasMoreDetails ON AssetMas.AssetID = AssetMasMoreDetails.AssetID
                                                    )
                                                    INNER JOIN (
                                                        EmpAssetAllocation
                                                        INNER JOIN PersonalInfoMas ON EmpAssetAllocation.PersonalInfoID = PersonalInfoMas.PersonalInfoID
                                                    ) ON AssetMas.AssetID = EmpAssetAllocation.AssetID
                                                ) ON ClientMas.ClientID = AssetCategoryMas.ClientID
                                            ) ON CurrentAssetStatus.CurrentAssetStatusID = AssetMas.CurrentAssetStatusID
                                        ) ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                    WHERE
                                        (
                                            ((ClientMas.ClientID) = " + clientId + @")
                                            AND ((AssetMas.IsActive) = True)
                                            AND ((AssetMas.IsDeleted) = False)
                                            AND ((EmpMas.IsActive) = True)
                                            AND ((EmpMas.IsDeleted) = False)
                                            AND ((PersonalInfoMas.GoldProfile) = False)
                                            AND ((EmpMas.ResignedStatus) = False)
                                        )
                                    ORDER BY
                                        AssetCategoryMas.AssetCatMasID,
                                        AssetMas.AssetID;";

                DataTable dt = new DataTable();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objAssetRegisterChartDataList = JsonConvert.DeserializeObject<List<AssetRegisterChartData>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                // Log if required
            }
            finally
            {
                if (conn != null)
                {
                    dbStaffSync.closeDBConnection();
                }
            }

            return objAssetRegisterChartDataList;
        }

        public List<ReimbursementInfoPendingList> PendingReimbursmentApprovalList(int txtClientID)
        {
            List<ReimbursementInfoPendingList> objReimbursementInfoPendingListInfo = new List<ReimbursementInfoPendingList>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "";

                strQuery = @"SELECT
                                EmpMas.EmpID,
                                EmpMas.EmpCode,
                                EmpMas.EmpName,
                                DesigMas.DesignationTitle,
                                DepMas.DepartmentTitle,
                                ReimbursRequestInfo.ReimbursRequestID,
                                ReimbursRequestInfo.ReimbursRequestCode,
                                ReimbursementHeaderMas.ReimbID,
                                ReimbursementHeaderMas.ReimbTitle,
                                ReimbursRequestInfo.ReimbursAproveBy1,
                                ReimbursRequestInfo.ReimbursRequestDate,
                                ReimbursRequestInfo.ReimbursRequestAmount,
                                ReimbursRequestInfo.ReimbursAproveComments1,
                                ReimbursRequestInfo.ReimbursAproveStatus1,
                                ReimbursRequestInfo.ReimbursRequestFinalStatus,
                                ReimbursRequestInfo.ReimbursAproveStatus2,
                                ReimbursRequestInfo.ReimbursAproveBy2,
                                IIf(ReimbursRequestInfo.ReimbursAproveStatus1 = False, ""Pending"", """") AS RequestStatus,
                                ReimbursRequestInfo.IsActive,
                                ReimbursRequestInfo.IsDeleted,
                                ClientMas.ClientID
                            FROM
                                ReimbursementHeaderMas
                                INNER JOIN (
                                    (
                                        (
                                            DesigMas
                                            INNER JOIN (
                                                DepMas
                                                INNER JOIN (
                                                    ClientMas
                                                    INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                            ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                        )
                                        INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                    )
                                    INNER JOIN ReimbursRequestInfo ON PersonalInfoMas.PersonalInfoID = ReimbursRequestInfo.PersonalInfoID
                                ) ON ReimbursementHeaderMas.ReimbID = ReimbursRequestInfo.ReimbID
                            WHERE
                                (
                                    ((EmpMas.EmpID) > 1)
                                    AND ((ReimbursRequestInfo.ReimbursAproveStatus1) = False)
                                    AND ((ReimbursRequestInfo.ReimbursRequestFinalStatus) = False)
                                    AND ((ReimbursRequestInfo.ReimbursAproveStatus2) = False)
                                    AND ((ReimbursRequestInfo.IsActive) = True)
                                    AND ((ReimbursRequestInfo.IsDeleted) = False)
                                    AND ((ClientMas.ClientID) = " + txtClientID + @")
                                )
                            ORDER BY
                                EmpMas.EmpID,
                                ReimbursRequestInfo.ReimbursRequestID,
                                ReimbursRequestInfo.ReimbursRequestDate;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objReimbursementInfoPendingListInfo = JsonConvert.DeserializeObject<List<ReimbursementInfoPendingList>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objReimbursementInfoPendingListInfo;
        }
    }
}
