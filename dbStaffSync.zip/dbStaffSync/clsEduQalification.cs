﻿using ModelStaffSync;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace dbStaffSync
{
    public class clsEduQalification
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset;
        clsGenFunc objGenFunc = new clsGenFunc();

        public List<EduQualTitleModel> GetEduQualMasList()
        {
            List<EduQualTitleModel> objQualificationList = new List<EduQualTitleModel>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM EduQualMas WHERE IsDeleted = false";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objQualificationList = JsonConvert.DeserializeObject<List<EduQualTitleModel>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objQualificationList;
        }

        public List<EduQualTitleModel> GetEduQualMasList(string filterText)
        {
            List<EduQualTitleModel> objQualificationList = new List<EduQualTitleModel>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM EduQualMas WHERE IsDeleted = false AND EduQualTitle LIKE '%" + filterText + "%'";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objQualificationList = JsonConvert.DeserializeObject<List<EduQualTitleModel>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objQualificationList;
        }

        public string GetEduQualByID(int intEduQualID)
        {
            string selectedEducQualTitle = string.Empty;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT EduQualTitle FROM EduQualMas WHERE EduQualID = " + intEduQualID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;

                cmd.Parameters.AddWithValue("@EduQualID", intEduQualID);
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    selectedEducQualTitle = Convert.ToString(result);
                }
                else
                {
                    selectedEducQualTitle = "";
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedEducQualTitle;
        }

        public int GetEduQualByTitle(string EduQualTitle)
        {
            int selectedEducQualID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT EduQualID FROM EduQualMas WHERE EduQualTitle = '" + EduQualTitle + "'";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;

                cmd.Parameters.AddWithValue("@EduQualTitle", EduQualTitle.Trim());
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    selectedEducQualID = Convert.ToInt32(result);
                }
                else
                {
                    selectedEducQualID = 0;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedEducQualID;
        }

        public int InsertEduQual(string txtEduQualCode, string txtEduQualTitle, string txtEduQualInitial, bool IsActive, bool IsDeleted)
        {
            int affectedRows = 0;
            try
            {

                Response<int> maxRowCount = objGenFunc.getMaxRowCount("EduQualMas", "EduQualID");
                
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO EduQualMas (EduQualID, EduQualCode, EduQualTitle, EduQualInitial, IsActive, IsDeleted) VALUES " +
                 "(" + maxRowCount.Data  + ",'" + "EDU-" + (maxRowCount.Data).ToString().PadLeft(4, '0').Trim() + "','" + txtEduQualTitle.Trim() + "','" + txtEduQualInitial.Trim() + "'," + IsActive + "," + IsDeleted + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

        public int UpdateEduQual(int txtEduQualID, string txtEduQualCode, string txtEduQualTitle, string txtEduQualInitial, bool IsActive, bool IsDeleted)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE EduQualMas SET " +
                 "EduQualCode = '" + txtEduQualCode.Trim() + "', EduQualTitle = '" + txtEduQualTitle.Trim() + "', EduQualInitial = '" + txtEduQualInitial.Trim() + "', IsActive = " + IsActive +
                 " WHERE EduQualID = " + txtEduQualID.ToString().Trim();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return affectedRows;
        }

        public int DeleteEduQual(int txtEduQualID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "DELETE * FROM EduQualMas WHERE EduQualID = " + txtEduQualID.ToString().Trim();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();

            }
            return affectedRows;
        }
    }
}
