﻿using ModelStaffSync;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace dbStaffSync
{
    public class clsAttendanceMas
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset;
        clsGenFunc objGenFunc = new clsGenFunc();

        public clsAttendanceMas() { 

        }

        public DateTime getLastAttendanceDate()
        {
            DateTime dtLastAttendanceDate = new DateTime();
            try
            {
                DataTable dt = new DataTable();
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT MAX(AttDate) AS LastAttendanceDate FROM EmpDailyAttendanceInfo WHERE AttStatus = 'Present'";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                if (dt.Rows.Count > 0 && dt.Rows[0]["LastAttendanceDate"] != DBNull.Value)
                {
                    dtLastAttendanceDate = Convert.ToDateTime(dt.Rows[0]["LastAttendanceDate"]);
                    dtLastAttendanceDate = dtLastAttendanceDate.AddDays(1);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return dtLastAttendanceDate;
        }

        public List<EmployeeAttendanceInfo> GetDefaultEmployeeAttendanceInfo(int txtEmpID, DateTime dtSelectedMonth)
        {
            List<EmployeeAttendanceInfo> objEmployeeAttendanceInfo = new List<EmployeeAttendanceInfo>();
            List<EmployeeAttendanceInfo> objReturnEmployeeAttendanceInfoList = new List<EmployeeAttendanceInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                //string strQuery = "SELECT * FROM qryEmpAttendanceList WHERE EmpID = " + txtEmpID + " AND AttDate = #" + dtSelectedMonth.Date.ToString("dd-MMM-yyyy") + "# ORDER BY AttDate, OrderID Asc";
                string strQuery = "SELECT * FROM qryEmpAttendanceList WHERE EmpID = " + txtEmpID + " AND Month(AttDate) = " + dtSelectedMonth.Date.Month + " AND Year(AttDate) = " + dtSelectedMonth.Date.Year + " ORDER BY AttDate, OrderID Asc";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeAttendanceInfo>>(DataTableToJSon);
                foreach (EmployeeAttendanceInfo indEmployeeAttendanceInfo in objEmployeeAttendanceInfo)
                {
                    objReturnEmployeeAttendanceInfoList.Add(new EmployeeAttendanceInfo
                    {
                        AttID = indEmployeeAttendanceInfo.AttID,
                        AttDate = indEmployeeAttendanceInfo.AttDate,
                        AttStatus = indEmployeeAttendanceInfo.AttStatus,
                        EmpID = indEmployeeAttendanceInfo.EmpID,
                        LeaveTRID = indEmployeeAttendanceInfo.LeaveTRID == null ? 0 : indEmployeeAttendanceInfo.LeaveTRID,
                        LeaveComments = indEmployeeAttendanceInfo.LeaveComments == null ? "" : indEmployeeAttendanceInfo.LeaveComments
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objReturnEmployeeAttendanceInfoList;
        }

        public List<EmployeeAttendanceInfo> GetDefaultEmployeeAttendanceInfoForJobs(int txtEmpID, DateTime dtSelectedMonth)
        {
            List<EmployeeAttendanceInfo> objEmployeeAttendanceInfo = new List<EmployeeAttendanceInfo>();
            List<EmployeeAttendanceInfo> objReturnEmployeeAttendanceInfoList = new List<EmployeeAttendanceInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = "SELECT * FROM qryEmpAttendanceList WHERE EmpID = " + txtEmpID + " AND AttDate = #" + dtSelectedMonth.Date.ToString("dd-MMM-yyyy") + "# ORDER BY AttDate, OrderID Asc";
                //string strQuery = "SELECT * FROM qryEmpAttendanceList WHERE EmpID = " + txtEmpID + " AND Month(AttDate) = " + dtSelectedMonth.Date.Month + " AND Year(AttDate) = " + dtSelectedMonth.Date.Year + " ORDER BY AttDate, OrderID Asc";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeAttendanceInfo>>(DataTableToJSon);
                foreach (EmployeeAttendanceInfo indEmployeeAttendanceInfo in objEmployeeAttendanceInfo)
                {
                    objReturnEmployeeAttendanceInfoList.Add(new EmployeeAttendanceInfo
                    {
                        AttID = indEmployeeAttendanceInfo.AttID,
                        AttDate = indEmployeeAttendanceInfo.AttDate,
                        AttStatus = indEmployeeAttendanceInfo.AttStatus,
                        EmpID = indEmployeeAttendanceInfo.EmpID,
                        LeaveTRID = indEmployeeAttendanceInfo.LeaveTRID == null ? 0 : indEmployeeAttendanceInfo.LeaveTRID,
                        LeaveComments = indEmployeeAttendanceInfo.LeaveComments == null ? "" : indEmployeeAttendanceInfo.LeaveComments
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objReturnEmployeeAttendanceInfoList;
        }

        public EmployeeTotalWorkingInfo GetEmployeeMonthlyWorkingDays(int txtEmpID, DateTime dtSelectedDateFrom, DateTime dtSelectedDateTo)
        {
            List<EmployeeTotalWorkingInfo> objEmployeeSpecificDailyAttendanceInfo = new List<EmployeeTotalWorkingInfo>();

            try
            {
                DataTable dt = new DataTable();

                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " EmpDailyAttendanceInfo.EmpID, " + 
                                        " Day(DateSerial (Year(AttDate), Month(AttDate) + 1, 0)) AS TotalDaysInMonth, " + 
                                        " Sum(IIf(AttStatus = 'Present', 1, 0)) AS PresentCount, " + 
                                        " Sum(IIf(AttStatus = 'Leave : Full Day', 1, 0)) AS FullDayLeaveCount, " + 
                                        " Sum(IIf(AttStatus = 'Leave : First Half', 1, 0)) AS FirstHalfLeaveCount, " + 
                                        " Sum(IIf(AttStatus = 'Leave : Second Half', 1, 0)) AS SecondHalfLeaveCount, " + 
                                        " FullDayLeaveCount + FirstHalfLeaveCount + SecondHalfLeaveCount AS TotalLeaveCount, " + 
                                        " [PresentCount] - [TotalLeaveCount] AS TotalWorkedDays " + 
                                    " FROM " + 
                                        " EmpDailyAttendanceInfo " + 
                                    " WHERE " + 
                                        " ( " + 
                                            " ( " + 
                                                " (EmpDailyAttendanceInfo.AttDate) >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# " + 
                                                " AND (EmpDailyAttendanceInfo.AttDate) < #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "# " + 
                                            " ) " + 
                                            " AND ((EmpDailyAttendanceInfo.EmpID) = " + txtEmpID + " ) " + 
                                        " ) " + 
                                    " GROUP BY " + 
                                        " EmpDailyAttendanceInfo.EmpID, Day(DateSerial (Year(AttDate), Month(AttDate) + 1, 0));";

                strQuery = "SELECT " +
                                    " DateDiff(\"d\", " + "#" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#) AS TotalDaysInMonth, " +
                                    " SUM(PresentVal) AS TotalPresent, " +
                                    " SUM(PaidLeaveVal) AS TotalPaidLeave, " +
                                    " SUM(LOPVal) AS TotalLossOfPay, " +
                                    " (DateDiff(\"d\", " + "#" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#)) - SUM(LOPVal) AS TotalPayableDays " +
                                " FROM " +
                                    " ( " +
                                        " SELECT " +
                                            " AttDate, " +
                                            " IIF(AttStatus = 'Present', 1, 0) AS PresentVal, " +
                                            " IIF( " +
                                                " AttStatus LIKE '*Full Day*' " +
                                                " AND AttStatus NOT LIKE '*Loss Of Pay*', " +
                                                " 1, " +
                                                " IIF( " +
                                                    " AttStatus LIKE '*First Half*' " +
                                                    " AND AttStatus LIKE '*Second Half*' " +
                                                    " AND AttStatus NOT LIKE '*Loss Of Pay*', " +
                                                    " 1, " +
                                                    " IIF( " +
                                                        " AttStatus LIKE '*First Half*' " +
                                                        " AND AttStatus NOT LIKE '*Loss Of Pay*', " +
                                                        " 0.5, " +
                                                        " IIF( " +
                                                            " AttStatus LIKE '*Second Half*' " +
                                                            " AND AttStatus NOT LIKE '*Loss Of Pay*', " +
                                                            " 0.5, " +
                                                            " 0 " +
                                                        " ) " +
                                                    " ) " +
                                                " ) " +
                                            " ) AS PaidLeaveVal, " +
                                            " IIF( " +
                                                " AttStatus LIKE '*Full Day - Loss Of Pay*', " +
                                                " 1, " +
                                                " IIF( " +
                                                    " AttStatus LIKE '*First Half - Loss Of Pay*' " +
                                                    " AND AttStatus LIKE '*Second Half - Loss Of Pay*', " +
                                                    " 1, " +
                                                    " IIF( " +
                                                        " AttStatus LIKE '*First Half - Loss Of Pay*', " +
                                                        " 0.5, " +
                                                        " IIF( " +
                                                            " AttStatus LIKE '*Second Half - Loss Of Pay*', " +
                                                            " 0.5, " +
                                                            " 0 " +
                                                        " ) " +
                                                    " ) " +
                                                " ) " +
                                            " ) AS LOPVal " +
                                        " FROM " +
                                            " EmpDailyAttendanceInfo " +
                                         " WHERE " +
                                            " AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate < #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "# " +
                                            " AND EmpID = " + txtEmpID +
                                    ") AS X;";

                strQuery = "SELECT " +
                                    "DateDiff(\"d\", #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#) AS TotalDaysInMonth," +
                                    "SUM(PresentVal) AS TotalPresent," +
                                    "SUM(PaidLeaveVal) AS TotalPaidLeave," +
                                    "SUM(LOPVal) AS TotalLossOfPay," +
                                    "(DateDiff(\"d\", #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#)) - SUM(LOPVal) AS TotalPayableDays" +
                                " FROM " +
                                    "(SELECT " +
                                            "AttDate, " +
                                            "IIF(AttStatus = 'Present', 1, 0) AS PresentVal, " + 
                                            "IIF(AttStatus LIKE '*Full Day*' AND AttStatus NOT LIKE '*Loss Of Pay', 1, " + 
                                            "IIF(AttStatus LIKE '*First Half*' AND AttStatus LIKE '*Second Half*' AND AttStatus NOT LIKE '*Loss Of Pay', 1, " + 
                                            "IIF(AttStatus LIKE '*First Half*' AND AttStatus NOT LIKE '*Loss Of Pay', 0.5, " + 
                                            "IIF(AttStatus LIKE '*Second Half*' AND AttStatus NOT LIKE '*Loss Of Pay', 0.5, 0)))) AS PaidLeaveVal, " + 
                                            "IIF(AttStatus LIKE '*Full Day - Loss Of Pay', 1, " + 
                                            "IIF(AttStatus LIKE '*First Half - Loss Of Pay' AND AttStatus LIKE '*Second Half - Loss Of Pay', 1, " + 
                                            "IIF(AttStatus LIKE '*First Half - Loss Of Pay', 0.5, " + 
                                            "IIF(AttStatus LIKE '*Second Half - Loss Of Pay', 0.5, 0)))) AS LOPVal " + 
                                        "FROM " + 
                                            "EmpDailyAttendanceInfo " + 
                                        "WHERE " + 
                                            "AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate <#" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "# AND EmpID = " + txtEmpID + ")" +
                                        " AS X;";

                strQuery = "SELECT " + 
                                " DateDiff(\"d\", #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#) AS TotalDaysInMonth, " +
                                " SUM(IIF(AttStatus = 'Present', 1, 0)) AS TotalPresent, " +
                                " ( " + 
                                    " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'Full Day') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Loss Of Pay') = 0, " + 
                                            " 1, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) + " +
                                    " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'First Half') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Second Half') = 0 " + 
                                            " AND InStr (1, AttStatus, 'Loss Of Pay') = 0, " + 
                                            " 0.5, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) + " + 
                                    " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'Second Half') > 0 " +
                                            " AND InStr (1, AttStatus, 'First Half') = 0 " + 
                                            " AND InStr (1, AttStatus, 'Loss Of Pay') = 0, " + 
                                            " 0.5, " + 
                                            " 0 " + 
                                        " ) " +
                                    " ) + " +
                                    " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'First Half') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Second Half') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Loss Of Pay') = 0, " + 
                                            " 1, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) " + 
                                " ) AS TotalPaidLeave, " + 
                                " ( " + 
                                    " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'Full Day - Loss Of Pay') > 0, " + 
                                            " 1, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) + " +
                                " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'First Half - Loss Of Pay') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Second Half - Loss Of Pay') = 0, " + 
                                            " 0.5, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) + " +
                                " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'Second Half - Loss Of Pay') > 0 " + 
                                            " AND InStr (1, AttStatus, 'First Half - Loss Of Pay') = 0, " + 
                                            " 0.5, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) + " +
                                " SUM( " + 
                                        " IIF( " + 
                                            " InStr (1, AttStatus, 'First Half - Loss Of Pay') > 0 " + 
                                            " AND InStr (1, AttStatus, 'Second Half - Loss Of Pay') > 0, " + 
                                            " 1, " + 
                                            " 0 " + 
                                        " ) " + 
                                    " ) " + 
                                " ) AS TotalLossOfPay, " + 
                                " DateDiff(\"d\", #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "#, #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#) - " +
                                " ( " +
                                    " SUM( " +
                                        " IIF( " +
                                            " InStr (1, AttStatus, 'Full Day - Loss Of Pay') > 0, " +
                                            " 1, " +
                                            " 0 " +
                                        " ) " +
                                    " ) + " +
                                    " SUM( " +
                                        " IIF( " +
                                            " InStr (1, AttStatus, 'First Half - Loss Of Pay') > 0 " +
                                            " AND InStr (1, AttStatus, 'Second Half - Loss Of Pay') = 0, " +
                                            " 0.5, " +
                                            " 0 " +
                                        " ) " +
                                    " ) + " +
                                    "SUM( " +
                                        " IIF( " +
                                            " InStr (1, AttStatus, 'Second Half - Loss Of Pay') > 0 " +
                                            " AND InStr (1, AttStatus, 'First Half - Loss Of Pay') = 0, " +
                                            " 0.5, " +
                                            " 0 " +
                                        " ) " +
                                    " ) + " +
                                    "SUM( " +
                                        " IIF( " +
                                            " InStr (1, AttStatus, 'First Half - Loss Of Pay') > 0 " +
                                            " AND InStr (1, AttStatus, 'Second Half - Loss Of Pay') > 0, " +
                                            " 1, " +
                                            " 0 " +
                                        " ) " +
                                    " ) " +
                                " ) AS TotalPayableDays " +
                            " FROM " +
                                " EmpDailyAttendanceInfo " +
                            " WHERE " +
                                " AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate <#" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "# AND EmpID = " + txtEmpID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeSpecificDailyAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeTotalWorkingInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objEmployeeSpecificDailyAttendanceInfo.Count > 0)
                return objEmployeeSpecificDailyAttendanceInfo[0];
            else
                return new EmployeeTotalWorkingInfo();
        }

        public EmployeeTotalWorkingInfo getTotalPresentDays(int txtEmpID, DateTime dtSelectedDateFrom, DateTime dtSelectedDateTo)
        {
            List<EmployeeTotalWorkingInfo> objEmployeeSpecificDailyAttendanceInfo = new List<EmployeeTotalWorkingInfo>();

            try
            {
                DataTable dt = new DataTable();

                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " SUM(IIF(AttStatus = 'Present', 1, 0)) AS TotalPresent " + 
                                   " FROM " + 
                                        " EmpDailyAttendanceInfo " + 
                                   " WHERE " +
                                        " AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate < #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#" + 
                                        " AND EmpID = " + txtEmpID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeSpecificDailyAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeTotalWorkingInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objEmployeeSpecificDailyAttendanceInfo.Count > 0)
                return objEmployeeSpecificDailyAttendanceInfo[0];
            else
                return new EmployeeTotalWorkingInfo();
        }

        public EmployeeTotalWorkingInfo getTotalLossOfPayDays(int txtEmpID, DateTime dtSelectedDateFrom, DateTime dtSelectedDateTo)
        {
            List<EmployeeTotalWorkingInfo> objEmployeeSpecificDailyAttendanceInfo = new List<EmployeeTotalWorkingInfo>();

            try
            {
                DataTable dt = new DataTable();

                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " SUM( " + 
                                            " IIF(AttStatus LIKE '*Full Day - Loss Of Pay*', 1," +
                                            " IIF(AttStatus LIKE '*First Half - Loss Of Pay*' AND AttStatus LIKE '*Second Half - Loss Of Pay*', 1," +
                                            " IIF(AttStatus LIKE '*First Half - Loss Of Pay*', 0.5," +
                                            " IIF(AttStatus LIKE '*Second Half - Loss Of Pay*', 0.5, 0 ))) " + 
                                            " )" + 
                                        " ) AS TotalLossOfPay " + 
                                    " FROM " + 
                                        " EmpDailyAttendanceInfo " + 
                                   " WHERE " +
                                        " AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate < #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#" +
                                        " AND EmpID = " + txtEmpID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeSpecificDailyAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeTotalWorkingInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objEmployeeSpecificDailyAttendanceInfo.Count > 0)
                return objEmployeeSpecificDailyAttendanceInfo[0];
            else
                return new EmployeeTotalWorkingInfo();
        }

        public EmployeeTotalWorkingInfo getTotalPaidLeave(int txtEmpID, DateTime dtSelectedDateFrom, DateTime dtSelectedDateTo)
        {
            List<EmployeeTotalWorkingInfo> objEmployeeSpecificDailyAttendanceInfo = new List<EmployeeTotalWorkingInfo>();

            try
            {
                DataTable dt = new DataTable();

                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " +
                                        "SUM(IIF(InStr (1, AttStatus, 'Full Day') > 0 AND InStr (1, AttStatus, 'Loss Of Pay') = 0, 1,0)) + " +
                                        "SUM(IIF(InStr (1, AttStatus, 'First Half') > 0 AND InStr (1, AttStatus, 'Second Half') = 0 AND InStr (1, AttStatus, 'Loss Of Pay') = 0, 0.5, 0)) + " +
                                        "SUM(IIF(InStr (1, AttStatus, 'Second Half') > 0 AND InStr (1, AttStatus, 'First Half') = 0 AND InStr (1, AttStatus, 'Loss Of Pay') = 0, 0.5, 0)) + " +
                                        "SUM(IIF(InStr (1, AttStatus, 'First Half') > 0 AND InStr (1, AttStatus, 'Second Half') > 0 AND InStr (1, AttStatus, 'Loss Of Pay') = 0, 1, 0)) AS TotalPaidLeave " +
                                   " FROM EmpDailyAttendanceInfo " +
                                   " WHERE " +
                                        " AttDate >= #" + dtSelectedDateFrom.ToString("dd-MMM-yyyy") + "# AND AttDate < #" + dtSelectedDateTo.ToString("dd-MMM-yyyy") + "#" +
                                        " AND EmpID = " + txtEmpID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeSpecificDailyAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeTotalWorkingInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objEmployeeSpecificDailyAttendanceInfo.Count > 0)
                return objEmployeeSpecificDailyAttendanceInfo[0];
            else
                return new EmployeeTotalWorkingInfo();
        }

        public EmployeeAttendanceInfo GetEmployeeSpecificDailyAttendanceInfo(int txtEmpID, DateTime dtSelectedDate)
        {
            List<EmployeeAttendanceInfo> objEmployeeSpecificDailyAttendanceInfo = new List<EmployeeAttendanceInfo>();

            try
            {
                DataTable dt = new DataTable();

                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " +
                                        " AttID, " +
                                        " AttDate, " +
                                        " AttStatus, " +
                                        " LeaveTRID, " +
                                        " EmpMas.EmpID " +
                                  " FROM " +
                                        " EmpMas INNER JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID " +
                                  " WHERE " +
                                        " (((EmpDailyAttendanceInfo.AttDate) = #" + dtSelectedDate.ToString("dd-MMM-yyyy") + "#) " +
                                        " AND ((EmpMas.EmpID) = " + txtEmpID + ")) ORDER BY EmpDailyAttendanceInfo.AttID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeSpecificDailyAttendanceInfo = JsonConvert.DeserializeObject<List<EmployeeAttendanceInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objEmployeeSpecificDailyAttendanceInfo.Count > 0)
                return objEmployeeSpecificDailyAttendanceInfo[0];
            else
                return new EmployeeAttendanceInfo();
        }

        public List<MonthlyAttendanceInfo> EmployeeSpecificMonthlyAttendanceInfo(int EmpID, DateTime ReportForTheMonth)
        {
            List<MonthlyAttendanceInfo> objMonthlyAttendanceReport = new List<MonthlyAttendanceInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = "SELECT * FROM qryMnthlyAttdInfo WHERE EmpID = " + EmpID + " AND AttdMonth = #" + ReportForTheMonth.Date.ToString("dd-MMM-yyyy") + "#";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objMonthlyAttendanceReport = JsonConvert.DeserializeObject<List<MonthlyAttendanceInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objMonthlyAttendanceReport;
        }

        public List<MonthlyAttendanceInfo> MonthlyAttendanceReport(DateTime ReportForTheMonth)
        {
            List<MonthlyAttendanceInfo> objMonthlyAttendanceReport = new List<MonthlyAttendanceInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = "SELECT * FROM qryMnthlyAttdInfo WHERE AttdMonth = #" + ReportForTheMonth.Date.ToString("dd-MMM-yyyy") + "#";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objMonthlyAttendanceReport = JsonConvert.DeserializeObject<List<MonthlyAttendanceInfo>>(DataTableToJSon);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            
            return objMonthlyAttendanceReport;
        }

        public List<MonthlyAttendanceInfo> DailyBatchAttendance(int txtCompanyID, DateTime ReportForTheMonth, string DayNumber)
        {
            List<MonthlyAttendanceInfo> objMonthlyAttendanceReport = new List<MonthlyAttendanceInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                //string strQuery = "SELECT ClientID, EmpID, EmpCode, EmpName, DesignationTitle, DepartmentTitle, qryMnthlyAttdInfo.SlNo, 'Present' AS " + DayNumber + " FROM qryMnthlyAttdInfo WHERE ClientID = " + txtCompanyID + " AND AttdMonth = #" + ReportForTheMonth.Date.ToString("dd-MMM-yyyy") + "#";

                string strQuery =
                    "SELECT " +
                    "    ClientMas.ClientID, " +
                    "    EmpMas.EmpID, " +
                    "    EmpMas.EmpCode, " +
                    "    EmpMas.EmpName, " +
                    "    DesigMas.DesignationTitle, " +
                    "    DepMas.DepartmentTitle, " +

                    "    CLng(" +
                    "        IIf(" +
                    "            IsNull(" +
                    "                DMax(" +
                    "                    'SlNo', " +
                    "                    'qryMnthlyAttdInfo', " +
                    "                    'EmpID=' & EmpMas.EmpID & " +
                    "                    ' AND ClientID=" + txtCompanyID + "'" +
                    "                    & ' AND AttdMonth=#" +
                                         ReportForTheMonth.Date.ToString("dd-MMM-yyyy") +
                                         "#'" +
                    "                )" +
                    "            ), " +
                    "            0, " +
                    "            DMax(" +
                    "                'SlNo', " +
                    "                'qryMnthlyAttdInfo', " +
                    "                'EmpID=' & EmpMas.EmpID & " +
                    "                ' AND ClientID=" + txtCompanyID + "'" +
                    "                & ' AND AttdMonth=#" +
                                     ReportForTheMonth.Date.ToString("dd-MMM-yyyy") +
                                     "#'" +
                    "            )" +
                    "        )" +
                    "    ) AS SlNo, " +

                    "    'Present' AS " + DayNumber + " " +

                    "FROM " +
                    "    ( " +
                    "        ( " +
                    "            ClientMas " +
                    "            INNER JOIN EmpMas " +
                    "                ON ClientMas.ClientID = EmpMas.ClientID " +
                    "        ) " +
                    "        INNER JOIN DepMas " +
                    "            ON EmpMas.DepartmentID = DepMas.DepartmentID " +
                    "    ) " +
                    "    INNER JOIN DesigMas " +
                    "        ON EmpMas.EmpDesignationID = DesigMas.DesignationID " +

                    "WHERE " +
                    "    ClientMas.ClientID = " + txtCompanyID + " " +
                    "    AND EmpMas.EmpID > 1 " +
                    "    AND EmpMas.IsActive = True " +
                    "    AND EmpMas.IsDeleted = False " +
                    "ORDER BY " +
                    "    EmpMas.EmpID, " +
                    "    EmpMas.EmpName;";

                strQuery = @"SELECT
                                ClientMas.ClientID,
                                EmpMas.EmpID,
                                EmpMas.EmpCode,
                                EmpMas.EmpName,
                                DesigMas.DesignationTitle,
                                DepMas.DepartmentTitle,
                                CLng (
                                    IIf(
                                        IsNull(
                                            DMax (
                                                'SlNo',
                                                'qryMnthlyAttdInfo',
                                                'EmpID=' & EmpMas.EmpID & ' AND ClientID=' & " + txtCompanyID + @" & ' AND AttdMonth=#" + ReportForTheMonth.Date.ToString("dd-MMM-yyyy") + @"#'
                                            )
                                        ),
                                        0,
                                        DMax (
                                            'SlNo',
                                            'qryMnthlyAttdInfo',
                                            'EmpID=' & EmpMas.EmpID & ' AND ClientID=' & " + txtCompanyID + @" & ' AND AttdMonth=#" + ReportForTheMonth.Date.ToString("dd-MMM-yyyy") + @"#'
                                        )
                                    )
                                ) AS SlNo,
                                'Present' AS " + DayNumber + @",
                                ShiftMas.ShiftStart,
                                ShiftMas.ShiftEnd
                            FROM
                                ShiftMas
                                INNER JOIN (
                                    (
                                        DesigMas
                                        INNER JOIN (
                                            DepMas
                                            INNER JOIN (
                                                ClientMas
                                                INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                            ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                        ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                    )
                                    INNER JOIN EmpShiftInfo ON EmpMas.EmpID = EmpShiftInfo.EmpID
                                ) ON ShiftMas.ShiftID = EmpShiftInfo.ShiftID
                            WHERE
                                (
                                    ((ClientMas.ClientID) = " + txtCompanyID + @")
                                    AND ((EmpMas.EmpID) > 1)
                                    AND ((EmpMas.IsActive) = True)
                                    AND ((EmpMas.IsDeleted) = False)
                                )
                            ORDER BY
                                EmpMas.EmpID,
                                EmpMas.EmpName;";

                strQuery = @"SELECT
                                    ClientMas.ClientID,
                                    EmpMas.EmpID,
                                    EmpMas.EmpCode,
                                    EmpMas.EmpName,
                                    DesigMas.DesignationTitle,
                                    DepMas.DepartmentTitle,
                                    CLng (
                                        IIf(
                                            IsNull(
                                                DMax (
                                                    'SlNo',
                                                    'qryMnthlyAttdInfo',
                                                    'EmpID=' & EmpMas.EmpID & ' AND ClientID=' & 1 & ' AND AttdMonth=#01-Nov-2026#'
                                                )
                                            ),
                                            0,
                                            DMax (
                                                'SlNo',
                                                'qryMnthlyAttdInfo',
                                                'EmpID=' & EmpMas.EmpID & ' AND ClientID=' & 1 & ' AND AttdMonth=#01-Nov-2026#'
                                            )
                                        )
                                    ) AS SlNo,
                                    'Present' AS Day16,
                                    ShiftMas.ShiftStart,
                                    ShiftMas.ShiftEnd
                                FROM
                                    (
                                        ShiftMas
                                        INNER JOIN (
                                            (
                                                DesigMas
                                                INNER JOIN (
                                                    DepMas
                                                    INNER JOIN (
                                                        ClientMas
                                                        INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID
                                                    ) ON DepMas.DepartmentID = EmpMas.DepartmentID
                                                ) ON DesigMas.DesignationID = EmpMas.EmpDesignationID
                                            )
                                            INNER JOIN EmpShiftInfo ON EmpMas.EmpID = EmpShiftInfo.EmpID
                                        ) ON ShiftMas.ShiftID = EmpShiftInfo.ShiftID
                                    )
                                    INNER JOIN PersonalInfoMas ON EmpMas.EmpID = PersonalInfoMas.EmpID
                                WHERE
                                    (
                                        ((ClientMas.ClientID) = " + txtCompanyID + @")
                                        AND ((EmpMas.EmpID) > 1)
                                        AND ((EmpMas.IsActive) = True)
                                        AND ((EmpMas.IsDeleted) = False)
                                        AND ((EmpMas.ResignedStatus) = False)
                                        AND ((PersonalInfoMas.GoldProfile) = False)
                                    )
                                ORDER BY
                                    EmpMas.EmpID,
                                    EmpMas.EmpName;";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objMonthlyAttendanceReport = JsonConvert.DeserializeObject<List<MonthlyAttendanceInfo>>(DataTableToJSon);
                if(objMonthlyAttendanceReport.Count == 0)
                {
                    strQuery = "SELECT ClientID, EmpID, EmpCode, EmpName, DesignationTitle, DepartmentTitle, qryMnthlyAttdInfo.SlNo, 'Present' AS " + DayNumber + " FROM qryMnthlyAttdInfo WHERE ClientID = " + txtCompanyID;

                    cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = strQuery;
                    cmd.ExecuteNonQuery();

                    da = new OleDbDataAdapter(cmd);
                    da.Fill(dt);

                    DataTableToJSon = "";
                    DataTableToJSon = JsonConvert.SerializeObject(dt);
                    objMonthlyAttendanceReport = JsonConvert.DeserializeObject<List<MonthlyAttendanceInfo>>(DataTableToJSon);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objMonthlyAttendanceReport;
        }

        public List<MonthlyAttendanceSummaryInfo> getMonthlyAttendanceSummaryInfo(int ClientID, DateTime txtDTFrom, DateTime txtDTTo)
        {
            List<MonthlyAttendanceSummaryInfo> objMonthlyAttendanceSummaryInfo = new List<MonthlyAttendanceSummaryInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = "SELECT " + 
                                        " Sum(IIf(StatusType = 'Present', 1, 0)) AS PresentEmployees, " +
                                        " Sum(IIf(StatusType = 'Leave', 1, 0)) AS LeaveEmployees, " +
                                        " Sum(IIf(StatusType = 'Half Leave', 1, 0)) AS HalfLeaveEmployees " +
                                    " FROM " +
                                        " ( " +
                                            " SELECT " +
                                                " EmpMas.EmpID, Max(EmpDailyAttendanceInfo.AttStatus) AS StatusType " +
                                            " FROM " +
                                                " ( " +
                                                    " ClientMas INNER JOIN EmpMas ON ClientMas.ClientID = EmpMas.ClientID " +
                                                " ) " +
                                                " INNER JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID " +
                                            " WHERE " +
                                                " EmpDailyAttendanceInfo.AttDate BETWEEN #" + Convert.ToDateTime(txtDTFrom).ToString("dd-MMM-yyyy") + "# AND #" + Convert.ToDateTime(txtDTTo).ToString("dd-MMM-yyyy") + "# " +
                                                " AND EmpMas.EmpID > 1 " + 
                                                " AND EmpMas.IsActive = True " +
                                                " AND EmpMas.IsDeleted = False " +
                                                " AND ClientMas.ClientID = " + ClientID + 
                                            " GROUP BY " +
                                                " EmpMas.EmpID " + 
                                        " )";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objMonthlyAttendanceSummaryInfo = JsonConvert.DeserializeObject<List<MonthlyAttendanceSummaryInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objMonthlyAttendanceSummaryInfo;
        }

        public List<EmployeeAttendanceClockInfo> getDailyLoginLogoutDefaultInformation(int EmpID)
        {
            List<EmployeeAttendanceClockInfo> objEmployeeAttendanceClockInfo = new List<EmployeeAttendanceClockInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = @"SELECT
                                        ShiftMas.ShiftID,
                                        ShiftMas.ShiftTitle,
                                        Format(ShiftMas.ShiftStart, ""hh:nn:ss AM/PM"") AS ShiftLoginTime,
                                        Format(ShiftMas.ShiftEnd, ""hh:nn:ss AM/PM"") AS ShiftLogoutTime,
                                        Format(ShiftMas.GracePeriod, ""hh:nn:ss AM/PM"") AS GracePeriod
                                    FROM
                                        ShiftMas
                                        INNER JOIN (
                                            EmpMas
                                            INNER JOIN EmpShiftInfo ON EmpMas.EmpID = EmpShiftInfo.EmpID
                                        ) ON ShiftMas.ShiftID = EmpShiftInfo.ShiftID
                                    WHERE
                                        (((EmpMas.EmpID) = " + EmpID + "));";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAttendanceClockInfo = JsonConvert.DeserializeObject<List<EmployeeAttendanceClockInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objEmployeeAttendanceClockInfo;
        }

        public List<EmployeeAttendanceClockInfo> getDailyLoginLogoutInformation(int EmpID, DateTime dtDate)
        {
            List<EmployeeAttendanceClockInfo> objEmployeeAttendanceClockInfo = new List<EmployeeAttendanceClockInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = @"SELECT
                                        ShiftMas.ShiftID,
                                        ShiftMas.ShiftTitle,
                                        Format(ShiftMas.ShiftStart, ""hh:nn:ss AM/PM"") AS ShiftLoginTime,
                                        Format(ShiftMas.ShiftEnd, ""hh:nn:ss AM/PM"") AS ShiftLogoutTime,
                                        Format(ShiftMas.GracePeriod, ""hh:nn:ss AM/PM"") AS GracePeriod,
                                        EmpDailyAttendanceInfo.AttID,
                                        EmpDailyAttendanceInfo.AttDate,
                                        EmpDailyAttendanceInfo.AttStatus,
                                        EmpDailyAttendanceInfo.LeaveTRID,
                                        Format(
                                            EmpDailyAttendanceInfo.LoginTime,
                                            ""hh:nn:ss AM/PM""
                                        ) AS LoginTime,
                                        Format(
                                            EmpDailyAttendanceInfo.LogoutTime,
                                            ""hh:nn:ss AM/PM""
                                        ) AS LogoutTime,
                                        Format(
                                            EmpDailyAttendanceInfo.TotalTime,
                                            ""hh:nn:ss AM/PM""
                                        ) AS TotalTime
                                    FROM
                                        (
                                            ShiftMas
                                            INNER JOIN (
                                                EmpMas
                                                INNER JOIN EmpShiftInfo ON EmpMas.EmpID = EmpShiftInfo.EmpID
                                            ) ON ShiftMas.ShiftID = EmpShiftInfo.ShiftID
                                        )
                                        LEFT JOIN EmpDailyAttendanceInfo ON EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID
                                    WHERE
                                        EmpMas.EmpID = " + EmpID + @"
                                        AND (
                                            EmpDailyAttendanceInfo.AttID = (
                                                SELECT
                                                    MAX(A2.AttID)
                                                FROM
                                                    EmpDailyAttendanceInfo AS A2
                                                WHERE
                                                    A2.EmpID = EmpMas.EmpID
                                            )
                                            OR EmpDailyAttendanceInfo.AttID IS NULL
                                        );";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objEmployeeAttendanceClockInfo = JsonConvert.DeserializeObject<List<EmployeeAttendanceClockInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objEmployeeAttendanceClockInfo;
        }


        public List<IsEmployeeOnLeave> IsEmployeeOnLeave(int EmpID, DateTime dtDate)
        {
            List<IsEmployeeOnLeave> objIsEmployeeOnLeave = new List<IsEmployeeOnLeave>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();
                //DateTime.Now.Month
                string strQuery = @"SELECT
                                        EmpMas.EmpID,
                                        #" + dtDate.ToString("dd-MMM-yyyy") + @"# AS CheckDate,
                                        EmpDailyAttendanceInfo.AttID,
                                        EmpDailyAttendanceInfo.AttStatus,
                                        EmpLeaveTransMas.LeaveTRID,
                                        EmpLeaveTransMas.LeaveTypeID,
                                        EmpLeaveTransMas.LeaveMode,
                                        EmpLeaveTransMas.LeaveDuration,
                                        EmpLeaveTransMas.ActualLeaveDateFrom,
                                        EmpLeaveTransMas.ActualLeaveDateTo,
                                        IIf(
                                            EmpLeaveTransMas.LeaveTRID IS NOT NULL,
                                            IIf(
                                                EmpLeaveTransMas.LeaveMode = ""Full Day"",
                                                ""On Leave - Full Day"",
                                                EmpLeaveTransMas.LeaveMode & "" Leave; Attendance: "" & Nz (EmpDailyAttendanceInfo.AttStatus, ""Not Marked"")
                                            ),
                                            Nz (EmpDailyAttendanceInfo.AttStatus, ""Not Marked"")
                                        ) AS DayStatus
                                    FROM
                                        (
                                            (
                                                EmpMas
                                                LEFT JOIN EmpDailyAttendanceInfo ON (
                                                    EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID
                                                    AND EmpDailyAttendanceInfo.AttDate = #" + dtDate.ToString("dd-MMM-yyyy") +  @"#
                                                )
                                            )
                                            LEFT JOIN EmpLeaveTransMas ON (
                                                EmpMas.EmpID = EmpLeaveTransMas.EmpID
                                                AND #" + dtDate.ToString("dd-MMM-yyyy") +  @"# BETWEEN EmpLeaveTransMas.ActualLeaveDateFrom AND EmpLeaveTransMas.ActualLeaveDateTo
                                                AND EmpLeaveTransMas.LeaveApprovalComments = ""Approved : Approved""
                                                AND EmpLeaveTransMas.LeaveRejectionComments = ""Not Rejected""
                                                AND EmpLeaveTransMas.Canceled = False
                                            )
                                        )
                                    WHERE
                                        EmpMas.EmpID = " + EmpID;

                strQuery = @"SELECT
                                EmpMas.EmpID,
                                #" + dtDate.ToString("dd-MMM-yyyy") + @"# AS CheckDate,
                                EmpDailyAttendanceInfo.AttID,
                                EmpDailyAttendanceInfo.AttStatus,
                                EmpLeaveTransMas.LeaveTRID,
                                EmpLeaveTransMas.LeaveTypeID,
                                EmpLeaveTransMas.LeaveMode,
                                EmpLeaveTransMas.LeaveDuration,
                                EmpLeaveTransMas.ActualLeaveDateFrom,
                                EmpLeaveTransMas.ActualLeaveDateTo,
                                IIf(
                                    EmpLeaveTransMas.LeaveTRID Is Not Null,
                                    IIf(
                                        EmpLeaveTransMas.LeaveMode = ""Full Day"",
                                        ""On Leave - Full Day"",

                                        EmpLeaveTransMas.LeaveMode &
                                        "" Leave; Attendance: "" &
                                        IIf(
                                            IsNull(EmpDailyAttendanceInfo.AttStatus),
                                            ""Not Marked"",
                                            EmpDailyAttendanceInfo.AttStatus
                                        )
                                    ),
                                    IIf(
                                        IsNull(EmpDailyAttendanceInfo.AttStatus),
                                        ""Not Marked"",
                                        EmpDailyAttendanceInfo.AttStatus
                                    )
                                ) AS DayStatus
                            FROM
                                (
                                    (
                                        EmpMas
                                        LEFT JOIN EmpDailyAttendanceInfo
                                        ON
                                            (
                                                EmpMas.EmpID = EmpDailyAttendanceInfo.EmpID
                                                AND EmpDailyAttendanceInfo.AttDate = #" + dtDate.ToString("dd-MMM-yyyy") + @"#
                                            )
                                    )
                                    LEFT JOIN EmpLeaveTransMas
                                    ON
                                        (
                                            EmpMas.EmpID = EmpLeaveTransMas.EmpID

                                            AND #" + dtDate.ToString("dd-MMM-yyyy") + @"# BETWEEN
                                                EmpLeaveTransMas.ActualLeaveDateFrom
                                                AND EmpLeaveTransMas.ActualLeaveDateTo

                                            AND EmpLeaveTransMas.LeaveApprovalComments =
                                                ""Approved : Approved""

                                            AND EmpLeaveTransMas.LeaveRejectionComments =
                                                ""Not Rejected""

                                            AND EmpLeaveTransMas.Canceled = False
                                        )
                                )
                            WHERE
                                EmpMas.EmpID = " + EmpID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objIsEmployeeOnLeave = JsonConvert.DeserializeObject<List<IsEmployeeOnLeave>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objIsEmployeeOnLeave;
        }

        public int InsertDailyAttendance(int txtEmpID, DateTime AttendanceDate, string AttendanceStatus, int LeaveTRID)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("EmpDailyAttendanceInfo", "AttID");

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO EmpDailyAttendanceInfo (AttID, EmpID, AttDate, AttStatus, LeaveTRID) VALUES " +
                 "(" + maxRowCount.Data + "," + txtEmpID + ",'" + AttendanceDate.ToString("dd-MMM-yyyy") + "','" + AttendanceStatus + "'," + LeaveTRID + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateDailyAttendance(int txtEmpID, DateTime AttendanceDate, string AttendanceStatus, int LeaveTRID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE EmpDailyAttendanceInfo SET AttStatus = '" + AttendanceStatus + "', LeaveTRID = " + LeaveTRID + 
                 " WHERE EmpID = " + txtEmpID + " AND AttDate = #" + AttendanceDate.ToString("dd-MMM-yyyy") + "#";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = affectedRows;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateDailyLogInTime(int txtEmpID, DateTime AttendanceDate, DateTime LoginTime, DateTime LateLoginTime)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE EmpDailyAttendanceInfo SET LoginTime = #" + LoginTime.ToString("hh:mm:ss tt") + "#, LateLoginTime = #" + LateLoginTime.ToString("hh:mm:ss tt") + "#" +
                 " WHERE EmpID = " + txtEmpID + " AND AttDate = #" + AttendanceDate.ToString("dd-MMM-yyyy") + "#";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = affectedRows;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateDailyLogOutTime(int txtEmpID, DateTime AttendanceDate, DateTime LogoutTime,DateTime TotalTime, DateTime LateLogoutTime)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE EmpDailyAttendanceInfo SET LogoutTime = #" + LogoutTime.ToString("hh:mm:ss tt") + "#, TotalTime = #" + TotalTime.ToString("hh:mm:ss tt") + "#, LateLogoutTime = #" + LateLogoutTime.ToString("hh:mm:ss tt") + "#" +
                 " WHERE EmpID = " + txtEmpID + " AND AttDate = #" + AttendanceDate.ToString("dd-MMM-yyyy") + "#";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = affectedRows;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }
    }
}
