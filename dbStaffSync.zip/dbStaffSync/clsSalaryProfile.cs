﻿//using C1.Framework;
using ModelStaffSync;
using Newtonsoft.Json;
//using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
//using static C1.Util.Win.Win32;

namespace dbStaffSync
{
    public class clsSalaryProfile
    {
        dbStaffSync dbStaffSync = new dbStaffSync();
        OleDbConnection conn = null;
        DataSet dtDataset = null;
        clsGenFunc objGenFunc = new clsGenFunc();
        Dictionary<string, string> formulaMap = new Dictionary<string, string>();

        public Dictionary<string, string> getSalaryHeadersList()
        {
            DataTable dt = new DataTable();
            formulaMap = new Dictionary<string, string>();
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT " + 
                                        " AllTitle As HeaderTitle, " + 
                                        " CalcFormula, " + 
                                        " ProrataBasis, " + 
                                        " MaxCap " + 
                                    " FROM " + 
                                        " AllowanceHeaderMas " + 
                                    " UNION ALL " + 
                                    " SELECT " +
                                        " DedTitle As HeaderTitle, " + 
                                        " CalcFormula, " + 
                                        " ProrataBasis, " + 
                                        " MaxCap " + 
                                    " FROM " + 
                                        " DeductionHeaderMas " + 
                                    " UNION ALL " + 
                                    " SELECT " +
                                        " ReimbTitle As HeaderTitle, " + 
                                        " CalcFormula, " + 
                                        " ProrataBasis, " + 
                                        " MaxCap " + 
                                    " FROM " + 
                                        " ReimbursementHeaderMas";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                if(dt.Rows.Count > 0)
                {
                    string headerTitle = "";
                    string formula = "";
                    foreach (DataRow dr in dt.Rows)
                    {
                        headerTitle = dr["HeaderTitle"].ToString().Trim();
                        formula = dr["CalcFormula"].ToString().Trim();

                        if (!formulaMap.ContainsKey(headerTitle))
                        {
                            formulaMap.Add(headerTitle, formula);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return formulaMap;
        }

        public SpecificEmployeeSalaryInfo getSpecificEmployeeSalaryInfo(int txtEmpID)
        {
            List<SpecificEmployeeSalaryInfo> objSpecificEmployeeSalaryInfoList = new List<SpecificEmployeeSalaryInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " TOP 1 EmpSalID, " + 
                                        " EmpSalDate, " + 
                                        " TotalAllowance, " + 
                                        " TotalDeduction, " + 
                                        " TotalReimbursement, " +
                                        " PFCalculatedAmount, " +
                                        " NetPayable, " + 
                                        " OrderID, " + 
                                        " EmpID, " +
                                        " StructureEntry " +
                                    " FROM " + 
                                        " EmpSalMas " + 
                                    " WHERE " +
                                        " EmpSalMas.StructureEntry = true AND EmpID = " + txtEmpID +  
                                    " ORDER BY " +
                                        " EmpSalMas.OrderID DESC;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSpecificEmployeeSalaryInfoList = JsonConvert.DeserializeObject<List<SpecificEmployeeSalaryInfo>>(DataTableToJSon);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            if (objSpecificEmployeeSalaryInfoList.Count == 0)
                return new SpecificEmployeeSalaryInfo();
            else
                return objSpecificEmployeeSalaryInfoList[0];
        }

        public int getEmployeeSalaryConfigStructure(int txtEmpID)
        {
            int intSalaryConfigStructureID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();
                DataTable dt = new DataTable();

                string strQuery = "SELECT " + 
                                        " TOP 1 EmpSalMas.EmpSalID " + 
                                    " FROM " + 
                                        " EmpSalMas " + 
                                    " WHERE " + 
                                        " EmpSalMas.EmpID = " + txtEmpID + 
                                    " ORDER BY " +
                                        " EmpSalMas.EmpSalID DESC;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    intSalaryConfigStructureID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return intSalaryConfigStructureID;
        }

        public decimal getOriginalSalaryActualAmount(int txtEmpID, int txtSalHeaderID, string txtHeaderType)
        {
            decimal SalHeaderAmount = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();
                DataTable dt = new DataTable();

                string strQuery = "SELECT " + 
                                        " TOP 1 EmpSalDetails.AllowanceAmount " + 
                                    " FROM " + 
                                        " EmpSalMas " + 
                                        " INNER JOIN EmpSalDetails ON EmpSalMas.EmpSalID = EmpSalDetails.EmpSalID " + 
                                    " WHERE " + 
                                        " ( " + 
                                            " ((EmpSalDetails.SalHeaderID) = " + txtSalHeaderID + ") " +
                                            " AND ((EmpSalDetails.SalHeaderType) = '" + txtHeaderType + "') " +
                                            " AND ((EmpSalMas.EmpID) = " + txtEmpID + " ) " + 
                                            " AND ((EmpSalMas.StructureEntry) = True) " + 
                                        " ) " + 
                                    " ORDER BY " + 
                                        " EmpSalMas.OrderID DESC;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    SalHeaderAmount = (decimal)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return SalHeaderAmount;
        }

        public List<SalaryProfileInfo> getEmployeeSpecificSalaryConfigStructure(int txtEmpID, int txtEmpSalID)
        {
            List<SalaryProfileInfo> objSalaryProfileInfo = new List<SalaryProfileInfo>();
            List<SalaryProfileInfo> objReturnSalaryProfileInfoList = new List<SalaryProfileInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        " EmpSalDetails.EmpSalDetID, " + 
                                        " EmpSalDetails.SalProDetID, " + 
                                        " EmpSalDetails.EmpSalID AS SalProfileID, " + 
                                        " EmpSalDetails.SalHeaderID AS HeaderID, " + 
                                        " EmpSalDetails.SalHeaderTitle AS HeaderTitle, " + 
                                        " EmpSalDetails.SalHeaderType AS HeaderType, " + 
                                        " EmpSalDetails.CalcFormula, " +
                                        " EmpSalDetails.CalcFormula AS CalcFormula1, " +
                                        " EmpSalDetails.AllowanceAmount AS ActualAmount, " +
                                        " EmpSalDetails.AllowanceAmount, " + 
                                        " EmpSalDetails.DeductionAmount, " + 
                                        " EmpSalDetails.ReimbursmentAmount, " + 
                                        " EmpSalDetails.OrderID " + 
                                    " FROM " +
                                        " EmpSalDetails " +
                                    " WHERE " +
                                        " EmpSalDetails.EmpSalID = " + txtEmpSalID +
                                    " ORDER BY " + 
                                        "EmpSalDetails.EmpSalDetID, EmpSalDetails.OrderID;";

                strQuery = "SELECT " + 
                                " EmpSalDetails.EmpSalDetID, " + 
                                " EmpSalDetails.SalProDetID, " + 
                                " EmpSalDetails.EmpSalID AS SalProfileID, " + 
                                " EmpSalDetails.SalHeaderID AS HeaderID, " + 
                                " EmpSalDetails.SalHeaderTitle AS HeaderTitle, " + 
                                " EmpSalDetails.SalHeaderType AS HeaderType, " + 
                                " EmpSalDetails.CalcFormula, " +
                                " EmpSalDetails.CalcFormula AS CalcFormula1, " +
                                " EmpSalDetails.AllowanceAmount AS ActualAmount, " + 
                                " EmpSalDetails.AllowanceAmount, " + 
                                " EmpSalDetails.DeductionAmount, " + 
                                " EmpSalDetails.ReimbursmentAmount, " + 
                                " EmpSalDetails.OrderID " + 
                            " FROM " + 
                                " EmpSalMas INNER JOIN EmpSalDetails ON EmpSalMas.EmpSalID = EmpSalDetails.EmpSalID " + 
                            " WHERE " + 
                                " ( " + 
                                    " ((EmpSalMas.StructureEntry) = True) " + 
                                    " AND ((EmpSalMas.EmpID) = " + txtEmpID + " ) " +
                                    " AND ((EmpSalDetails.EmpSalID) = " + txtEmpSalID + " ) " +
                                " ) " + 
                            " ORDER BY " + 
                                " EmpSalDetails.EmpSalDetID,EmpSalDetails.OrderID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);
                foreach (SalaryProfileInfo indSalaryProfileInfo in objSalaryProfileInfo)
                {
                    objReturnSalaryProfileInfoList.Add(new SalaryProfileInfo
                    {
                        EmpSalDetID = indSalaryProfileInfo.EmpSalDetID,
                        SalProDetID = indSalaryProfileInfo.SalProDetID,
                        SalProfileID = indSalaryProfileInfo.SalProfileID,
                        HeaderID = indSalaryProfileInfo.HeaderID,
                        HeaderTitle = indSalaryProfileInfo.HeaderTitle,
                        HeaderType = indSalaryProfileInfo.HeaderType,
                        CalcFormula = indSalaryProfileInfo.CalcFormula,
                        CalcFormula1 = indSalaryProfileInfo.CalcFormula1,
                        ActualAmount = getOriginalSalaryActualAmount(txtEmpID, indSalaryProfileInfo.HeaderID, indSalaryProfileInfo.HeaderType),
                        AllowanceAmount = indSalaryProfileInfo.AllowanceAmount,
                        DeductionAmount = indSalaryProfileInfo.DeductionAmount,
                        ReimbursmentAmount = indSalaryProfileInfo.ReimbursmentAmount,
                        OrderID = indSalaryProfileInfo.OrderID
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objReturnSalaryProfileInfoList;
        }

        public int getEmployeeSalaryConfigStructureInfo(int txtEmpID)
        {
            int intSalaryConfigStructureID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();
                DataTable dt = new DataTable();

                string strQuery = "SELECT " +
                                        " TOP 1 EmpSalMas.EmpSalID " +
                                    " FROM " +
                                        " EmpSalMas " +
                                    " WHERE " +
                                        " EmpSalMas.EmpID = " + txtEmpID +
                                    " ORDER BY " +
                                        " EmpSalMas.EmpSalID DESC;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    intSalaryConfigStructureID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return intSalaryConfigStructureID;
        }



        public SpecificEmployeeSalaryProfileInfo getEmployeeSpecificSalaryProfile(int txtEmpID)
        {
            SpecificEmployeeSalaryProfileInfo specificEmployeeSalaryProfileInfo = new SpecificEmployeeSalaryProfileInfo();
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();
                DataTable dt = new DataTable();

                string strQuery = "SELECT " +
                                    "EmpSalProfileInfo.EmpSalProID, " +
                                    "EmpSalProfileInfo.SalProfileID " +
                                "FROM " +
                                    "EmpSalProfileInfo " +
                                "WHERE " +
                                    "(" +
                                        "((EmpSalProfileInfo.EmpID) = " + txtEmpID + ") " +
                                        "AND((EmpSalProfileInfo.IsActive) = True) " +
                                        "AND((EmpSalProfileInfo.IsDeleted) = False) " +
                                        "AND((EmpSalProfileInfo.IsDefault) = True) " +
                                    ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                List<SpecificEmployeeSalaryProfileInfo> objEmployeeSalaryProfileInfo = JsonConvert.DeserializeObject<List<SpecificEmployeeSalaryProfileInfo>>(DataTableToJSon);
                if (objEmployeeSalaryProfileInfo.Count > 0)
                {
                    specificEmployeeSalaryProfileInfo.EmpID = objEmployeeSalaryProfileInfo[0].EmpID;
                    specificEmployeeSalaryProfileInfo.EmpSalProfileID = objEmployeeSalaryProfileInfo[0].EmpSalProfileID;
                    specificEmployeeSalaryProfileInfo.SalProfileID = objEmployeeSalaryProfileInfo[0].SalProfileID;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return specificEmployeeSalaryProfileInfo;
        }

        public List<SalaryProfileTitleList> GetSalProfileTitleList()
        {
            DataTable dt = new DataTable();
            List<SalaryProfileTitleList> objSalaryProfileInfoList = new List<SalaryProfileTitleList>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT SalProfileID, SalProfileCode, SalProfileTitle, SalProfileDescription, IsActive, IsDeleted, OrderID, IsAutomaticCalculation FROM SalProfileMas WHERE IsActive = true AND IsDeleted = false ORDER BY OrderID Asc";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfoList = JsonConvert.DeserializeObject<List<SalaryProfileTitleList>>(DataTableToJSon);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objSalaryProfileInfoList;
        }

        public List<SalaryProfileTitleList> GetSalProfileTitleList(string filterText)
        {
            DataTable dt = new DataTable();
            List<SalaryProfileTitleList> objSalaryProfileInfoList = new List<SalaryProfileTitleList>();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT SalProfileID, SalProfileCode, SalProfileTitle, SalProfileDescription, IsActive, IsDeleted, OrderID, IsAutomaticCalculation FROM SalProfileMas WHERE IsActive = true AND IsDeleted = false AND SalProfileTitle LIKE '" + filterText + "%' ORDER BY OrderID Asc";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfoList = JsonConvert.DeserializeObject<List<SalaryProfileTitleList>>(DataTableToJSon);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return objSalaryProfileInfoList;
        }

        public int GetAllowenceProfileDetailID(int txtSalaryProfileID, int txtAllowenceID)
        {
            int selectedAllowenceProfileDetailID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        "SalProfileDetails.SalProDetID, " +
                                        "SalProfileDetails.SalProAmount, " +
                                        "SalProfileDetails.AllID, " +
                                        "SalProfileMas.SalProfileID " +
                                    "FROM " + 
                                        "SalProfileMas " +
                                        "INNER JOIN SalProfileDetails ON SalProfileMas.SalProfileID = SalProfileDetails.SalProfileID " +
                                    "WHERE " +
                                        "( " +
                                            "((SalProfileDetails.AllID) = " + txtAllowenceID + ") " +
                                            "AND ((SalProfileMas.SalProfileID) = " + txtSalaryProfileID + " ) " +
                                        ");";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    selectedAllowenceProfileDetailID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedAllowenceProfileDetailID;
        }

        public int GetDeductionProfileDetailID(int txtSalaryProfileID, int txtDeductionID)
        {
            int selectedAllowenceProfileDetailID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        "SalProfileDetails.SalProDetID, " + 
                                        "SalProfileDetails.SalProAmount, " + 
                                        "SalProfileDetails.DedID, " + 
                                        "SalProfileMas.SalProfileID " + 
                                    "FROM " +
                                        "SalProfileMas " + 
                                        "INNER JOIN SalProfileDetails ON SalProfileMas.SalProfileID = SalProfileDetails.SalProfileID " + 
                                    "WHERE " + 
                                        "( " + 
                                            "((SalProfileDetails.DedID) = " + txtDeductionID + ") " + 
                                            "AND ((SalProfileMas.SalProfileID) = " + txtSalaryProfileID + ") " + 
                                        ");";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    selectedAllowenceProfileDetailID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedAllowenceProfileDetailID;
        }

        public int IsSalaryAlreadyProcessed(string strMonthYear)
        {
            int intSalaryProcessedID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                string strQuery = "SELECT " +
                                        "EmpSalMas.EmpSalID, " +
                                        "EmpSalMas.EmpSalMonthYear " +
                                  "FROM " +
                                        "EmpSalMas " +
                                    "WHERE " + 
                                        "EmpSalMas.EmpSalMonthYear = '" + strMonthYear + "'";
                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    intSalaryProcessedID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return intSalaryProcessedID;
        }

        public int GetReimbursementProfileDetailID(int txtSalaryProfileID, int txtReimbursementID)
        {
            int selectedAllowenceProfileDetailID = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                                        "SalProfileDetails.SalProDetID, " + 
                                        "SalProfileDetails.SalProAmount, " + 
                                        "SalProfileDetails.ReimbID, " + 
                                        "SalProfileMas.SalProfileID " + 
                                    "FROM " + 
                                        "SalProfileMas " + 
                                        "INNER JOIN SalProfileDetails ON SalProfileMas.SalProfileID = SalProfileDetails.SalProfileID " + 
                                    "WHERE " + 
                                        "(" + 
                                            "((SalProfileDetails.ReimbID) = " + txtReimbursementID + ") " + 
                                            "AND ((SalProfileMas.SalProfileID) = " + txtSalaryProfileID + ") " + 
                                        ");";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                object a = cmd.ExecuteScalar();
                if (a != null)
                    selectedAllowenceProfileDetailID = (int)a;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return selectedAllowenceProfileDetailID;
        }

        public DataTable GetSalaryInfoForBatchProcess(int txtClientID, DateTime dtSalaryDate)
        {
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT * FROM qryConsolidatedSalaryStatement WHERE EmpSalDate <= #" + dtSalaryDate.Date.ToString("dd-MMM-yyyy") + "# ORDER BY EmpID Asc";
                strQuery = "SELECT * FROM tmpQrySalPivotTable WHERE ClientID = " + txtClientID  + " ORDER BY EmpID Asc";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                //objSalaryProfileInfoList = JsonConvert.DeserializeObject<List<SalaryProfileTitleList>>(DataTableToJSon);
                dt = (DataTable)JsonConvert.DeserializeObject(DataTableToJSon, (typeof(DataTable)));

                if (dt.Rows.Count > 0)
                {
                    DataRow dr1 = dt.NewRow();
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        if (i > 5)
                        {
                            //var sum = dt.AsEnumerable().Where(r => !r.IsNull(i)).Sum(r => Convert.ToDouble(r[i]));
                            dr1[i] = "0.00";
                        }
                    }
                    dt.Rows.Add(dr1);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }

            return dt;
        }

        public List<SalaryProfileInfo> GetDefaultSalaryProfileInfo(int SalaryProfileID)
        {

            List<SalaryProfileInfo> objSalaryProfileInfo = new List<SalaryProfileInfo>();
            List<SalaryProfileInfo> objReturnSalaryProfileInfoList = new List<SalaryProfileInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " +
                                    "SalProfileDetails.SalProDetID, " +
                                    "SalProfileDetails.SalProfileID, " +
                                    "AllowanceHeaderMas.AllID AS HeaderID, " +
                                    "AllowanceHeaderMas.AllTitle AS HeaderTitle, " +
                                    "AllowanceHeaderMas.CalcFormula, " +
                                    "AllowanceHeaderMas.CalcFormula AS CalcFormula1, " +
                                    "AllowanceHeaderMas.IsFixed, " +
                                    "SalProfileDetails.SalProAmount " +
                                "FROM " +
                                    "SalProfileDetails " +
                                    "INNER JOIN AllowanceHeaderMas ON SalProfileDetails.AllID = AllowanceHeaderMas.AllID " +
                                "WHERE " +
                                    "(" +
                                        "((SalProfileDetails.SalProfileID) = " + SalaryProfileID + ") " +
                                        "AND ((AllowanceHeaderMas.IsActive) = True) " +
                                        "AND ((AllowanceHeaderMas.IsDeleted) = False) " +
                                    ") " +
                                "ORDER BY " +
                                    " SalProfileDetails.SalProDetID, AllowanceHeaderMas.OrderID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);

                if (objSalaryProfileInfo.Count == 0)
                {
                    strQuery = "SELECT " +
                                "0 AS SalProDetID," +
                                "0 AS SalProfileID," +
                                "AllowanceHeaderMas.AllID AS HeaderID," +
                                "AllowanceHeaderMas.AllTitle AS HeaderTitle," +
                                "AllowanceHeaderMas.CalcFormula," +
                                "AllowanceHeaderMas.CalcFormula AS CalcFormula1, " +
                                "AllowanceHeaderMas.IsFixed," +
                                "0 AS SalProAmount " +
                            "FROM " +
                                "AllowanceHeaderMas " +
                            " WHERE " +
                                "(" +
                                    " ((AllowanceHeaderMas.IsActive) = True) " +
                                    " AND ((AllowanceHeaderMas.IsDeleted) = False) " +
                                ") " +
                            " " +
                                "";
                    cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = strQuery;
                    cmd.ExecuteNonQuery();

                    da = new OleDbDataAdapter(cmd);
                    da.Fill(dt);

                    DataTableToJSon = "";
                    DataTableToJSon = JsonConvert.SerializeObject(dt);
                    objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);
                }
                foreach (SalaryProfileInfo indSalaryProfileInfo in objSalaryProfileInfo)
                {
                    objReturnSalaryProfileInfoList.Add(new SalaryProfileInfo
                    {
                        EmpSalDetID = 0,
                        SalProDetID = indSalaryProfileInfo.SalProDetID,
                        SalProfileID = indSalaryProfileInfo.SalProfileID,
                        HeaderID = indSalaryProfileInfo.HeaderID,
                        HeaderTitle = indSalaryProfileInfo.HeaderTitle,
                        HeaderType = "Allowences",
                        CalcFormula = indSalaryProfileInfo.CalcFormula,
                        CalcFormula1 = indSalaryProfileInfo.CalcFormula1,
                        IsFixed = indSalaryProfileInfo.IsFixed,
                        AllowanceAmount = indSalaryProfileInfo.SalProAmount,
                        DeductionAmount = 0,
                        ReimbursmentAmount = 0
                    });
                }

                strQuery = "SELECT " + 
                                "SalProfileDetails.SalProDetID, " +
                                "SalProfileDetails.SalProfileID, " +
                                "DeductionHeaderMas.DedID AS HeaderID, " +
                                "DeductionHeaderMas.DedTitle AS HeaderTitle, " +
                                "DeductionHeaderMas.CalcFormula, " +
                                "DeductionHeaderMas.CalcFormula AS CalcFormula1, " +
                                "DeductionHeaderMas.IsFixed, " +
                                "SalProfileDetails.SalProAmount " +
                            "FROM " +
                                "SalProfileDetails " +
                                "INNER JOIN DeductionHeaderMas ON SalProfileDetails.DedID = DeductionHeaderMas.DedID " +
                            "WHERE " +
                                "(" +
                                    "((SalProfileDetails.SalProfileID) = " + SalaryProfileID + ") " +
                                    "AND ((DeductionHeaderMas.IsActive) = True) " +
                                    "AND ((DeductionHeaderMas.IsDeleted) = False) " +
                                ") " +
                            "ORDER BY " +
                                " SalProfileDetails.SalProDetID, DeductionHeaderMas.OrderID";

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                dt = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfo = new List<SalaryProfileInfo>();
                objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);

                if (objSalaryProfileInfo.Count == 0)
                {
                    strQuery = "SELECT " +
                                    "0 AS SalProDetID, " +
                                    "0 AS SalProfileID, " +
                                    "DeductionHeaderMas.DedID AS HeaderID, " +
                                    "DeductionHeaderMas.DedTitle AS HeaderTitle, " +
                                    "DeductionHeaderMas.CalcFormula, " +
                                    "DeductionHeaderMas.CalcFormula AS CalcFormula1, " +
                                    "DeductionHeaderMas.IsFixed, " +
                                    "0 AS SalProAmount " +
                                "FROM " +
                                    "DeductionHeaderMas " +
                                "WHERE " +
                                    "( " +
                                        "((DeductionHeaderMas.IsActive) = True)  " +
                                        "AND ((DeductionHeaderMas.IsDeleted) = False)  " +
                                    ") " +
                                "ORDER BY " +
                                    " DeductionHeaderMas.OrderID;";

                    cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = strQuery;
                    cmd.ExecuteNonQuery();

                    dt = new DataTable();
                    da = new OleDbDataAdapter(cmd);
                    da.Fill(dt);

                    DataTableToJSon = "";
                    DataTableToJSon = JsonConvert.SerializeObject(dt);
                    objSalaryProfileInfo = new List<SalaryProfileInfo>();
                    objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);
                }

                foreach (SalaryProfileInfo indSalaryProfileInfo in objSalaryProfileInfo)
                {
                    objReturnSalaryProfileInfoList.Add(new SalaryProfileInfo
                    {
                        EmpSalDetID = 0,
                        SalProDetID = indSalaryProfileInfo.SalProDetID,
                        SalProfileID = indSalaryProfileInfo.SalProfileID,
                        HeaderID = indSalaryProfileInfo.HeaderID,
                        HeaderTitle = indSalaryProfileInfo.HeaderTitle,
                        HeaderType = "Deductions",
                        CalcFormula = indSalaryProfileInfo.CalcFormula,
                        CalcFormula1 = indSalaryProfileInfo.CalcFormula1,
                        IsFixed = indSalaryProfileInfo.IsFixed,
                        AllowanceAmount = 0,
                        DeductionAmount = indSalaryProfileInfo.SalProAmount,
                        ReimbursmentAmount = 0
                    });
                }

                strQuery = "SELECT " + 
                            "SalProfileDetails.SalProDetID, " + 
                            "SalProfileDetails.SalProfileID, " +
                            "ReimbursementHeaderMas.ReimbID AS HeaderID, " +
                            "ReimbursementHeaderMas.ReimbTitle AS HeaderTitle, " +
                            "ReimbursementHeaderMas.CalcFormula, " +
                            "ReimbursementHeaderMas.CalcFormula AS CalcFormula1, " +
                            "ReimbursementHeaderMas.IsFixed, " +
                            "SalProfileDetails.SalProAmount " +
                        "FROM " +
                            "SalProfileDetails " +
                            "INNER JOIN ReimbursementHeaderMas ON SalProfileDetails.ReimbID = ReimbursementHeaderMas.ReimbID " +
                        "WHERE " +
                            "(" +
                                "((SalProfileDetails.SalProfileID) = " + SalaryProfileID + ") " +
                                "AND ((ReimbursementHeaderMas.IsActive) = True) " +
                                "AND ((ReimbursementHeaderMas.IsDeleted) = False) " +
                            ") " +
                        "ORDER BY " +
                            " SalProfileDetails.SalProDetID, ReimbursementHeaderMas.OrderID; ";

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                dt = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfo = new List<SalaryProfileInfo>();
                objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);

                if (objSalaryProfileInfo.Count == 0)
                {
                    strQuery = "SELECT " +
                                    "0 AS SalProDetID, " +
                                    "0 AS SalProfileID, " +
                                    "ReimbursementHeaderMas.ReimbID AS HeaderID, " +
                                    "ReimbursementHeaderMas.ReimbTitle AS HeaderTitle, " +
                                    "ReimbursementHeaderMas.CalcFormula, " +
                                    "ReimbursementHeaderMas.CalcFormula AS CalcFormula1, " +
                                    "ReimbursementHeaderMas.IsFixed, " +
                                    "0 AS SalProAmount " +
                                "FROM " +
                                    "ReimbursementHeaderMas " +
                                "WHERE " +
                                    "( " +
                                        "((ReimbursementHeaderMas.IsActive) = True) " +
                                        "AND ((ReimbursementHeaderMas.IsDeleted) = False) " +
                                    ") " +
                                "ORDER BY " +
                                    "ReimbursementHeaderMas.OrderID;";

                    cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = strQuery;
                    cmd.ExecuteNonQuery();

                    dt = new DataTable();
                    da = new OleDbDataAdapter(cmd);
                    da.Fill(dt);

                    DataTableToJSon = "";
                    DataTableToJSon = JsonConvert.SerializeObject(dt);
                    objSalaryProfileInfo = new List<SalaryProfileInfo>();
                    objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);
                }
                foreach (SalaryProfileInfo indSalaryProfileInfo in objSalaryProfileInfo)
                {
                    objReturnSalaryProfileInfoList.Add(new SalaryProfileInfo
                    {
                        EmpSalDetID = 0,
                        SalProDetID = indSalaryProfileInfo.SalProDetID,
                        SalProfileID = indSalaryProfileInfo.SalProfileID,
                        HeaderID = indSalaryProfileInfo.HeaderID,
                        HeaderTitle = indSalaryProfileInfo.HeaderTitle,
                        CalcFormula = indSalaryProfileInfo.CalcFormula,
                        CalcFormula1 = indSalaryProfileInfo.CalcFormula1,
                        IsFixed = indSalaryProfileInfo.IsFixed,
                        HeaderType = "Reimbursement",
                        AllowanceAmount = 0,
                        DeductionAmount = 0,
                        ReimbursmentAmount = indSalaryProfileInfo.SalProAmount
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objReturnSalaryProfileInfoList;
        }

        public List<SalaryProfileInfo> GetEmployeeSpecificSalaryProfileInfo(int txtEmpID)
        {

            List<SalaryProfileInfo> objSalaryProfileInfo = new List<SalaryProfileInfo>();
            List<SalaryProfileInfo> objReturnSalaryProfileInfoList = new List<SalaryProfileInfo>();
            DataTable dt = new DataTable();

            try
            {
                conn = dbStaffSync.openDBConnection();

                string strQuery = "SELECT " + 
                        "EmpSalDetails.EmpSalDetID, " + 
                        "EmpSalDetails.SalProDetID, " +
                        "EmpSalDetails.EmpSalID as SalProfileID, " +
                        "EmpSalDetails.SalHeaderID as HeaderID, " +
                        "EmpSalDetails.SalHeaderTitle as HeaderTitle, " + 
                        "EmpSalDetails.SalHeaderType as HeaderType, " +
                        "EmpSalDetails.CalcFormula, " +
                        "EmpSalDetails.CalcFormula AS CalcFormula1, " +
                        "EmpSalDetails.AllowanceAmount, " + 
                        "EmpSalDetails.DeductionAmount, " + 
                        "EmpSalDetails.ReimbursmentAmount, " + 
                        "EmpSalDetails.OrderID " + 
                    "FROM " + 
                        "EmpSalMas " + 
                        "INNER JOIN EmpSalDetails ON EmpSalMas.EmpSalID = EmpSalDetails.EmpSalID " + 
                    "WHERE " + 
                        "(" + 
                            "(" + 
                                "(EmpSalMas.[EmpSalID]) = (" + 
                                    "SELECT " + 
                                        "MAX(EmpSalID) " + 
                                    "FROM " + 
                                        "EmpSalMas " + 
                                    "WHERE " + 
                                        "EmpID = " + txtEmpID + //" AND [EmpSalMas].[EmpSalMonthYear] = 'Jan - 1900' " + 
                                ") " + 
                            ") " + 
                        ") " + 
                    "ORDER BY " + 
                        "EmpSalDetails.EmpSalDetID, " + 
                        "EmpSalDetails.OrderID;";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.ExecuteNonQuery();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                string DataTableToJSon = "";
                DataTableToJSon = JsonConvert.SerializeObject(dt);
                objSalaryProfileInfo = JsonConvert.DeserializeObject<List<SalaryProfileInfo>>(DataTableToJSon);
                foreach (SalaryProfileInfo indSalaryProfileInfo in objSalaryProfileInfo)
                {
                    objReturnSalaryProfileInfoList.Add(new SalaryProfileInfo
                    {
                        EmpSalDetID = indSalaryProfileInfo.EmpSalDetID,
                        SalProDetID = indSalaryProfileInfo.SalProDetID,
                        SalProfileID = indSalaryProfileInfo.SalProfileID,
                        HeaderID = indSalaryProfileInfo.HeaderID,
                        HeaderTitle = indSalaryProfileInfo.HeaderTitle,
                        HeaderType = indSalaryProfileInfo.HeaderType,
                        CalcFormula = indSalaryProfileInfo.CalcFormula,
                        CalcFormula1 = indSalaryProfileInfo.CalcFormula1,
                        AllowanceAmount = indSalaryProfileInfo.AllowanceAmount,
                        DeductionAmount = indSalaryProfileInfo.DeductionAmount,
                        ReimbursmentAmount = indSalaryProfileInfo.ReimbursmentAmount,
                        OrderID = indSalaryProfileInfo.OrderID
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return objReturnSalaryProfileInfoList;
        }

        public int InsertSalaryProfileInfo(string txtSalProfileCode, string txtSalProfileTitle, string txtSalProfileDescription, bool IsActive, bool IsDeleted)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("SalProfileMas", "SalProfileID");

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO SalProfileMas (SalProfileID, SalProfileCode, SalProfileTitle, SalProfileDescription, IsActive, IsDeleted, IsDefault, OrderID) VALUES " +
                 "(" + maxRowCount.Data + ",'" + "SPF-" + (maxRowCount.Data).ToString().PadLeft(4, '0').Trim() + "','" + txtSalProfileTitle + "','" + txtSalProfileDescription + "'," + IsActive + "," + IsDeleted + ", false, " + maxRowCount + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int InsertSalaryProfileDetailInfo(int txtSalProfileID, int txtAllID, int txtDedID, int txtReimbID, decimal txtSalProAmount)
        {
            int affectedRows = 0;
            try
            {
                Response<int> maxRowCount = objGenFunc.getMaxRowCount("SalProfileDetails", "SalProDetID");

                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "INSERT INTO SalProfileDetails (SalProDetID, SalProfileID, AllID, DedID, ReimbID, SalProAmount) VALUES " +
                 "(" + maxRowCount.Data + "," + txtSalProfileID + "," + txtAllID + "," + txtDedID + "," + txtReimbID + "," + txtSalProAmount + ")";

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = maxRowCount.Data;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateSalaryProfileInfo(int txtSalaryProfileID, string txtSalaryProfileCode, string txtSalaryProfileTitle, string txtSalaryProfileDescription, bool IsActive, bool IsDeleted)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE SalProfileMas SET SalProfileCode = '" + txtSalaryProfileCode + "', SalProfileTitle = '" + txtSalaryProfileTitle + "', SalProfileDescription = '" + txtSalaryProfileDescription + "', IsActive = " + IsActive +
                 " WHERE SalProfileID = " + txtSalaryProfileID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = txtSalaryProfileID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateSalaryProfileInfoAutomaticCalculationStatus(int txtSalaryProfileID, bool IsAutomaticCalculationRequired)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE SalProfileMas SET IsAutomaticCalculation = " + IsAutomaticCalculationRequired + 
                 " WHERE SalProfileID = " + txtSalaryProfileID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = txtSalaryProfileID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int UpdateSalaryProfileDetailInfo(int SalProDetID, int txtSalProfileID, int txtAllID, int txtDedID, int txtReimbID, decimal txtSalProAmount)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "UPDATE SalProfileDetails SET SalProfileID = " + txtSalProfileID + ", AllID = " + txtAllID + ", DedID = " + txtDedID + ", ReimbID = " + txtReimbID + ", SalProAmount = " + txtSalProAmount +
                 " WHERE SalProDetID = " + SalProDetID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = SalProDetID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }

        public int DeleteSalaryProfileInfo(int txtSalaryProfileID)
        {
            int affectedRows = 0;
            try
            {
                conn = dbStaffSync.openDBConnection();
                dtDataset = new DataSet();

                string strQuery = "DELETE * FROM SalProfileMas WHERE SalProfileID = " + txtSalaryProfileID;

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                    affectedRows = txtSalaryProfileID;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Staffsync", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn = dbStaffSync.closeDBConnection();
            }
            finally
            {
                conn = dbStaffSync.closeDBConnection();
            }
            return affectedRows;
        }
    }
}
