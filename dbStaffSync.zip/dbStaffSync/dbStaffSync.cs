﻿using Common.Helpers;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace dbStaffSync
{
    public class dbStaffSync
    {
        //string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\StaffsyncDB.accdb";
        string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Development\\StaffSync\\StaffSync\\bin\\Debug\\StaffsyncDB.accdb";
        OleDbConnection conn = null;

        public OleDbConnection openDBConnection()
        {
            TrustedTimeAccessManager.Instance.EnsureAccess();

            conn = new OleDbConnection(connString);
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();

            return conn;
        }

        public OleDbConnection CreateDBConnection()
        {
            TrustedTimeAccessManager.Instance.EnsureAccess();

            OleDbConnection connection = new OleDbConnection(connString);
            connection.Open();

            return connection;
        }

        public OleDbConnection closeDBConnection()
        {
            if (conn == null)
                return null;

            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
            //if (conn.State == System.Data.ConnectionState.Closed)
            //    conn.Open();

            return conn;
        }
    }
}
